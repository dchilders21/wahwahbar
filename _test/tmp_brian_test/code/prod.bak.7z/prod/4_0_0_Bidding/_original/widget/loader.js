(function () {

	var biddingSources = "http://test.wahwahnetworks.com/brian/tb4/biddingsources.json.txt";
	
    var wahwah = window.wahwah;
	var widgetId = wahwah.id;
		// Multiple widget in same page support
     var uuid = (new Date()).getTime();
	 wahwah.uuid = uuid;
	
	/////////////////////////////////////	
    // Tracking
    /////////////////////////////////////
	
	var trackURL = "http://trk.platformpanda.com/rptrk.gif?";
	
	if (!Date.now) {
		Date.now = function() { return new Date().getTime(); }
	}
	
	var imgArray = [];

	function rpAddImage(img){
		var current = imgArray.length;
		imgArray[current] = document.createElement("img");
		imgArray[current].setAttribute("src", img);
	}
	
	function rpTrack(event, parameterPairs)
	{
		var str = "";
		if (parameterPairs != null)
			{
			for (key in parameterPairs)
			{
				str += "&" + key + "=" + parameterPairs[key];
			}
		}
		var ts = Date.now();
		var url = trackURL + "event=" + event + "&u=" + uuid + "&prd=" + widgetId + "&ts=" + ts + str;
		rpAddImage(url);
		// Do console message after to track asap. Because we track request almost immediately, don't use rpMsg stuff here
		logMsg = "event:" + event + " widgetId:" + widgetId + " requestTs:" + uuid + " ts:" + ts;
		if (typeof(wwLog) != "undefined")
			wwLog.call(wwConsole, wwPrefix, logMsg);
		else if (typeof(console.log) != "undefined")
		{
			console.log("[Wahwah Loader]  " + logMsg);
		}
	}
	
	
	/////////////////////////////////////	
    // Init tracker
    /////////////////////////////////////
	
	// We call this first because errors could happen when
	// gathering info for init tracker
	rpTrack("init", null);
	
	/////////////////////////////////////	
    // Request tracker
    /////////////////////////////////////
	
    function getDisplayType() // formerly getPlacementType
    {
    	var displaySize = screen.width;

    	if (displaySize <= 1024) {
            return "Mobile";
        } else if (displaySize > 1024) {
            return "Desktop";
        }

    }
	
	var ua = navigator.userAgent
	var isMobile = ua.indexOf("Mobile") != -1;
	var uaBrowser = "Unknown";
	if (ua.indexOf("Chrome/") != -1)
		uaBrowser = "Chrome";
	if ((ua.indexOf("Safari/") != -1 || ua.indexOf("AppleWebKit/") != -1) && !(uaBrowser == "Chrome"))
		uaBrowser = "Safari";
	if (ua.indexOf("Opera") != -1)
		uaBrowser = "Opera";
	if (uaBrowser == "Unknown")
	{
		if (ua.indexOf("MSIE") != -1 || ua.indexOf("Trident/") != -1)
			uaBrowser = "IE";
		else if (ua.indexOf("Edge/") != -1)
		{
				uaBrowser = "Edge";
		}
		else
		{
			if (ua.indexOf("Mozilla") != -1 && ua.indexOf("WebKit") == -1 && ua.indexOf("KHTML") == -1 && ua.indexOf("like Gecko") == -1)
				uaBrowser = "Firefox"; // Just treat all Mozilla browsers as Firefox, so know check against string "Firefox"
		}
	}
	
	
	var referrer = document.referrer || window.location.href;
	var domain = (referrer.split("//")[1]).split('/')[0];

    if (typeof(wahwahArray) == 'undefined') { wahwahArray = []; }
    wahwahArray[uuid] = wahwah;
	
	
	rpTrack("request", {"displayType" : getDisplayType(), "domain": domain, "browser": uaBrowser} );
	

	
	rpTrack("garbage_bad_tracker", {'foo': 'bar'});
	
    /////////////////////////////////////	
    // Init
    /////////////////////////////////////
	

    var mainWindow = window;
    var pubInDapIFContainer = null;
    var pubInDapIFFrame = null;
    var pubInDapIFWindow = null;
	
	
	
	


	
	// DEBUGGING
	
	var isDebug = false;
	if (typeof(wahwah.DEBUG_MODE) != "undefined" && wahwah.DEBUG_MODE.toString() == "true") 
		isDebug = true;
	wahwah.adconfig["DEBUG_MODE"] = isDebug;	// For use in ad modules
	
	if (typeof(wahwah.logLevel) == "undefined")
		wahwah.logLevel = "info";
	if (typeof(wahwah.debugMode) != "undefined" && wahwah.debugMode == true)
		wahwah.logLevel = "debug";
		
	if (!Date.now) {
		Date.now = function() { return new Date().getTime(); }
	}
	

    /////////////////////////////////////	
    // Client features
    /////////////////////////////////////
	

	if (!wahwah.hasOwnProperty("clientFeatures"))
	{
		wwLog.call(wwConsole, wwPrefix, "clientFeatures: NONE");
		wahwah.clientFeatures = {};
	}
	else
	{
		var msg = "clientFeatures: ";
		for (name in wahwah.clientFeatures) 
		{
			if (wahwah.clientFeatures.hasOwnProperty(name)) 
			{
				msg += name + ",";
			}
		}
		msg = msg.slice(0, -1); // last comma
	}
	
	
	if (wahwah.clientFeatures.hasOwnProperty("customPublisherReportKeys"))
	{ 
		wwLog.call(wwConsole, wwPrefix, "clientFeature - customPublisherReportKeys:");
		var WAHWAH_PARSED_PUBLISHER_KEYS = wahwah.clientFeatures.customPublisherReportKeyValues = {};
		// customPublisherReportKeys should always be in charge of what publisher report keys are sent, because platform needs to know
		var reportKeysArray = wahwah.clientFeatures.customPublisherReportKeys.split(";");
		for (var idx = 0; idx < reportKeysArray.length; idx++) 
		{
		
			var key = reportKeysArray[idx];
			// If it's a key in WAHWAH_PUBLISHER_KEYS, add it. If it's a missing key, make it null.
			if ( typeof(WAHWAH_PUBLISHER_KEYS) != "undefined" && WAHWAH_PUBLISHER_KEYS.hasOwnProperty(key))
			{
				WAHWAH_PARSED_PUBLISHER_KEYS[key] = WAHWAH_PUBLISHER_KEYS[key];
				wwLog.call(wwConsole, wwPrefix, "customPublisherReportKeys[" + key + "] = '"+WAHWAH_PARSED_PUBLISHER_KEYS[key]+"'");
			}
			else
			{
				// If it's a missing key, make it null and throw a warning
				WAHWAH_PARSED_PUBLISHER_KEYS[key] = null;
				wwWarn.call(wwConsole, wwPrefix, "customPublisherReportKeys[" + key + "] not found (re-traffic tag?). Setting to null");
			}
		}
		// If it's in WAHWAH_PUBLISHER_KEYS but no longer in customPublisherReportKeys, warn. (Need to retraffic?)
		if ( typeof(WAHWAH_PUBLISHER_KEYS) != "undefined" )
		{
			for (key in WAHWAH_PUBLISHER_KEYS) 
			{
				if (!WAHWAH_PARSED_PUBLISHER_KEYS.hasOwnProperty(key))
				{
					wwWarn.call(wwConsole, wwPrefix, "WAHWAH_PUBLISHER_KEYS[" + key + "] has been removed on platform and will be ignored. Re-traffic?");
				}
			}
		}
	}

	/////////////////////////////////////	
	// Messaging
	/////////////////////////////////////
		
		
	/* Avoid `console` errors in browsers that lack a console. Modified based on: http://html5boilerplate.com/ */ (function() { var method; var noop = function () {}; var methods = ['debug','error','info', 'log','warn']; var length = methods.length; var console = (window.console = window.console || {}); /* Loader.js only */ window.oldConsole = console; /* End Loader.js only */ while (length--) { method = methods[length]; /* Only stub undefined methods. */ if (!console[method]) { console[method] = noop; } } }()); /* First, check if IE running in Quirks mode, which treats window.console.log as an object, not ECMAScript function, and doesn't support .call on that object */ if (typeof(window.console.log.call) != "function") { console.warn("[Wahwah] This debugger doesn't support console.* as a function / console.log.call, etc. Possibly IE in Quirks/Compatibility mode or Firebug. View on web or localhost (not local or intranet) and in HTML5 or use a debug toolbar that supports console.* as a true ECMAScript function.");  /* Next, create console.log placeholder if it doesn't exist */	window.console = { 	debug : function() {}, 	error: function() {}, info: function() {}, 	log: function() {}, warn: function() {} }; }; /* Create addListener placeholder, when it doesn't exist */ var addListener = function (e, t, n) { if ("addEventListener" in e) { e.addEventListener(t, n, true) } else if ("attachEvent" in e) { var r = function () { n(window.event) }; e.attachEvent("on" + t, r) } }; var removeListener = function (e, t, n) { if ("removeEventListener" in e) { e.removeEventListener(t, n, true) } else if ("detachEvent" in e) { var r = function () { n(window.event) }; e.detachEvent("on" + t, r) } }

	// Todo: Pass up the parent window chain when possible
	// Later, replace with htm5 BroadcastChannel message when all browsers support to decrease size
	

	if (typeof(window.rpMsg) == "undefined")
	{
		window.rpMsg = new function() {
			this._module = "Loader";
			this._prefix = function(module)
			{
				if (module == null)
				{
					module = this._module;
				}
				return "[Wahwah " + module + "] ";
			}
			this._debugLevelInt = function()
			{
				switch(wahwah.logLevel)
				{
					case "debug":
						return 3;
						break;
					case "info":
						return 2;
						break;
					case "warn":
						return 1;
						break;
					case "error":
						return 0;
						break;
					default:
						return 0;
				}
			}
			this.forceLogProto = function()
			{
				return console.log;
			}
			this.errorProto = function() 
			{
				if (this._debugLevelInt() >= 0)
					return console.error;
				else
					return (function () {})
			}
			this.warnProto = function() 
			{
				if (this._debugLevelInt() >= 1)
					return console.warn;
				else
					return (function () {})
			}
			this.logProto = function() 
			{
				if (this._debugLevelInt() >= 2)
					return console.log;
				else
					return (function () {})
			}
			this.debugProto = function() 
			{
				if (this._debugLevelInt() >= 3)
					return console.debug;
				else
					return (function () {})
			}
			this.infoProto = function() {return this.logProto()}
		}
	}

    // easier minification
    var wwConsole = window.console;
    var wwPrefix = window.rpMsg._prefix(null);
    var wwLog = window.rpMsg.logProto();
    var wwWarn = window.rpMsg.warnProto();
    var wwDebug = window.rpMsg.debugProto();
    var wwError = window.rpMsg.errorProto();
    var wwInfo = window.rpMsg.infoProto();
    var wwForceLog = window.rpMsg.forceLogProto(); // Use sparingly
	
    var domain = wahwah.domain, baseUrl = wahwah.baseUrl;

    wwForceLog.call(wwConsole, wwPrefix, 'Red Panda :: ' + wahwah.version);
	wwForceLog.call(wwConsole, wwPrefix, 'Widget Id: ' + wahwah.id);
	wwLog.call(wwConsole, wwPrefix, 'Domain: ' + domain + ' | Base URL: ' + baseUrl);
	wwForceLog.call(wwConsole, wwPrefix, "Debug level: " + wahwah.logLevel + " (" + window.rpMsg._debugLevelInt() + ")");
	if (typeof(window.__RedPanda_Passback) != "undefined")
	{
		wwForceLog.call(wwConsole, wwPrefix, 'Parent network ad detected. This is a marketplace ad. Passback to network tag supported');
	}
	
	function windowLoaded()
	{
		if (!domAccessible)
			domAvailable();
			
		rpTrack("pageloaded", null);
		
        removeListener(window, "load", windowLoaded);	
	}
	
	function domAvailable()
	{	
		if (domAccessible)
			return;
			
		domAccessible = true;
		
		rpTrack("pageready", null);
		
		
		wwDebug.call(wwConsole, wwPrefix, "DOM now available. Sending " + msgQueue.length + " queued messages."); // Todo - is it even possible to have queued messages?
		
	    removeListener(document, "DOMContentLoaded", domAvailable);
		
		for (var i in msgQueue)
		{
			receiveMessage(msgQueue[i]);	// Only send message after DOM is available
		}
		
		if (!isLoaded)
			startLoad();
	}
	
	
    /////////////////////////////////////	
    // Main functionality
    /////////////////////////////////////
	
	var startTime = getTime();
	wwDebug.call(wwConsole, wwPrefix, "start time ts="+ startTime);

	var isLoaded = false;
	var domAccessible = false;

	var msgQueue = [];

	
	
/////////////////////////////////////	
// InDapIF friendly iframe functionality
/////////////////////////////////////
	
    wwLog.call(wwConsole, wwPrefix, "Checking for inDapIF/inFIF friendly frame...");
    if (window.inDapIF == true || window.inFIF == true)
    {
    	// If we are just serving standard inAd Format don't need to do anything here
    	if (!((inAd)&&(!breakOutAd))||(purchBusinessNewsDaily)||(marketPlaceTag)) {

	        mainWindow = parent;
			mainWindow.wahwah = wahwah;
	        // Now find container div
	        window.uuid = uuid;
	        var parentIframes = mainWindow.document.getElementsByTagName("iframe");
	        // If we are breaking out of the inPage Ad we don't want to target the FiF
	        for (var frmItr = 0; frmItr < parentIframes.length; frmItr++)
		    {
		        	// Looking to see if we're in a FiF
		        try {
			        if (parentIframes[frmItr].contentWindow === window)
			        {
			            wwDebug.call(wwConsole, wwPrefix, "Friendly Frame Match found");

				        if (!breakOutAd) { // Should remodify this a bit
			                
				            wwDebug.call(wwConsole, wwPrefix, "Assigning pubInDapIFContainer..." + parentIframes[frmItr].parentNode);
						    pubInDapIFContainer = parentIframes[frmItr].parentNode;
						    pubInDapIFFrame = parentIframes[frmItr];
						    pubInDapIFWindow = parentIframes[frmItr].contentWindow;
					    	
					    	if (typeof(mainWindow.wahwahArray) == 'undefined') { mainWindow.wahwahArray = []; }
					    	
					    	mainWindow.wahwahArray[uuid] = wahwahArray[uuid];

					    	if (purchBusinessNewsDaily) { 
                                wwDebug.call(wwConsole, wwPrefix, "We are on Purch Business News Daily");
                                if(findPosY(pubInDapIFFrame) >= 1500) {
                                    wwDebug.call(wwConsole, wwPrefix, "Not the highest FiF so stopping the loading...");
                                    return;
                                }
                            }
					    	// targeting the parent window for now
					    	//initMessaging(parentIframes[frmItr].contentWindow);
					    	initMessaging(parent.window);
				        } else {
				            wwDebug.call(wwConsole, wwPrefix, "But we're 'Breaking Out' so don't want to use pubInDapIFContainer");
				            initMessaging(parent.window);
				            pubInDapIFFrame = parentIframes[frmItr];
				        }
				    }
			    } 

		        catch(e)
		        {
		            console.log("access error. shouldn't happen");  // BB - temp
		        }
		    }

		    // Need to switch the window back to the current window
			// for Purch...Just needed to find the pubInDapIFContainer so we can resize it
			if (purchBusinessNewsDaily)
			    mainWindow = window;
		}
    }

    // Need to target the window that we use to wait for the DOM to load
    // Either the DFP FiF or the mainWindow
    var targetWindow = pubInDapIFWindow || mainWindow;

    /////////////////////////////////////	
    // Main functionality
    /////////////////////////////////////

	// DEBUGGING
	
	var isDebug = false;
	if (typeof(wahwah.DEBUG_MODE) != "undefined" && wahwah.DEBUG_MODE.toString() == "true") 
		isDebug = true;
	wahwah.adconfig["DEBUG_MODE"] = isDebug;	// For use in ad modules
	
	// Will be tracking load seperately
	if (mainWindow.document.readyState === "complete") 
	{
        setTimeout(windowLoaded);
    }
    else 
	{
		addListener(targetWindow, "load", windowLoaded);
    }
	
    if (mainWindow.document.readyState === "complete" || targetWindow.document.readyState === "interactive") 
	{
        setTimeout(domAvailable);
    }
    else 
	{
		addListener(targetWindow.document, "DOMContentLoaded", domAvailable);	
    }
	

		
	
    function startLoad() 
	{
	
		bidSourceRequest();
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
    /////////////////////////////////////	
    // Messaging
    /////////////////////////////////////
	
	
    var ModuleEnums = {
        MODULE_LOADER: "Loader",
        MODULE_ADS: "Ads"
    };
	
	function sendMessage(destID, message) {
        switch (destID) {
            case ModuleEnums.MODULE_ADS:
            	friendlyAdFrames[tmpIDHack].contentWindow.postMessage(message, '*');
                break;
        }
    }
	
	
    function receiveMessage(event) {
		try {
			var messageObj = JSON.parse(event.data);
		}
		catch(e)
		{
            return;
		}

		if (!domAccessible)
		{
			msgQueue[msgQueue.length] = event;
			return;
		}

        if ( domain !== "*" && event.origin !== domain) 
        {
           if (typeof(messageObj) == "undefined" || typeof(messageObj.vendor)== "undefined" || messageObj.vendor != "WahWah" )
               return;
        }

        if (messageObj.destination != ModuleEnums.MODULE_LOADER) {
            sendMessage(messageObj.destination, event.data);
        }
        else {

            if (messageObj.id == uuid) {
			
			
			
			
			
			
			
			
			// Todo messages here
			
			
			}
			
		}
	}
	
	/////////////////////////////////////	
    // File request
    /////////////////////////////////////
	
	function fileRequest(url, successcallback, failcallback)
	{
		wwDebug.call(wwConsole, wwPrefix, "Request URL using XMLHttpRequest START: " + url);
		var oReq = new XMLHttpRequest();
		var statusText = "";
		oReq.addEventListener("load", transferComplete);
		oReq.addEventListener("error", transferFailed);
		oReq.addEventListener("abort", transferCanceled);
		oReq.onreadystatechange = function (oEvent) {  
			if (oReq.readyState != 4)
			{
				statusText = oReq.statusText;
			}  
		}; 		
		
		function transferComplete(evt) // still may be a failure
		{
			var xhttp = evt.currentTarget;
			if (xhttp.readyState == 4 && (xhttp.status == 200 || xhttp.status == 304))
			{
				wwLog.call(wwConsole, wwPrefix, "Request URL using XMLHttpRequest SUCCESS: "+ url);
				successcallback.call(successcallback, event.currentTarget.responseText);
			}
			else
			{
				transferFailed(evt);
			}
		}
		
		function transferFailed(evt)
		{
			wwDebug.call(wwConsole, wwPrefix, "Request URL using XMLHttpRequest FAIL: "+ url);
			fileRequestFallbackFlash(url, successcallback, failcallback, statusText);
		}
		
		function transferCanceled(evt)
		{
			wwDebug.call(wwConsole, wwPrefix, "Cancelled transfer, treating as failed!");
			transferFailed(evt); // Probably shouldn't happen, so just treat as the same
		}
		
		oReq.open("GET", url);
		oReq.send();
		
		
		
	}
	
	function fileRequestFallbackFlash(url, successcallback, failcallback, errorMsg1)
	{
		wwLog.call(wwConsole, wwPrefix, "Request back up method - URL using Flash START: "+ url);
		ajaxFlash(url, flashSuccess, flashFail);
		
		function flashSuccess(data)
		{
			wwLog.call(wwConsole, wwPrefix, "Request back up method - URL using Flash SUCCESS: "+ url);
			successcallback.call(successcallback, data);
		}
		
		function flashFail(errorMsg2)
		{
			wwDebug.call(wwConsole, wwPrefix, "Request back up method - URL using Flash FAIL: "+ url);
			failcallback.call(failcallback, errorMsg1, errorMsg2);
		}
	
	}
	
	
    /////////////////////////////////////	
    // 1x1 url requester
    /////////////////////////////////////

	
	function createCallbackMethod(callback)
	{
		var ts = (new Date().getTime());
		var methodName = "_callback_" + ts;

		while(methodName in window)
		{
			methodName += "_";
		}

		window[methodName] = function (data)
		{
			callback(data);
		}

		return methodName;
	}

    var _ = function (id) {
        return document.getElementById(id);
    };

    var hasFlashStarted = false;
    var flashStartQueue = [];

    function send(destination, data) {
        data.timestamp = (new Date().getTime());
        data.rnd = Math.random();

        var key = "wahwah.tab.message." + destination;
        var value = JSON.stringify(data);

        // console.log("Sending on: [" + destination + "] => " + data);

        window.localStorage.setItem(key, value);
    }

    function listen(destination, callback) {
        var key = "wahwah.tab.message." + destination;

        addListener(window, "storage", function (e) {

            if (e.key == key) {
                // console.log("Receiving on: [" + destination + "] => " + e.newValue);

                var data = JSON.parse(e.newValue);
                callback(data);
            }
        })
    }

    function sendFlash(destination, data) {
        if (!hasFlashStarted) {
            flashStartQueue.push(function () {
                sendFlash(destination, data);
            })

            return;
        }

        _("tabMessageFlash").sendTabMessage(destination, data);
    }

    function listenFlash(destination, callback) {
        if (!hasFlashStarted) {
            flashStartQueue.push(function () {
                listenFlash(destination, callback);
            })

            return;
        }

        var methodName = createCallbackMethod(function (data) {
            callback(data);
        });

        _("tabMessageFlash").listenTabMessage(destination, methodName);
    }

    function initFlash() {
        hasFlashStarted = true;
    }

	
    function loadFlash() {


		var startMethodName = createCallbackMethod(function (data) { initFlash() });
	
        var swfurl = baseUrl + "widget/ajaxflash.swf?startMethod=" + startMethodName;
		
		var attributes = 'data="' + swfurl + '" type="application/x-shockwave-flash"';
		if (typeof(window.ActiveXObject) != "undefined")
				attributes = 'codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,2,0" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"'; // IE9
		var flashvars = "senzariDomain=&startMethod=" + startMethodName;
		var objTag = '<object id="rpFlash1x1" name="rpFlash1x1" width="1" height="1" id="rpFlash1x1" '+attributes+'><param name="movie" value="' + swfurl + '" /><param name="FlashVars" value="'+flashvars+'" /><param name="allowfullscreen" value="false"/><param name="allowscr'+'iptaccess" value="always" /><param name="scale" value="scale" /><param name="quality" value="low" /><param name="bgcolor" value="#ffffff" /><param name="wmode" value="transparent"/></object>';
		var div = document.createElement('div');
		div.style.width = "1px";
		div.style.maxHeight = "1px";
		div.style.height = "1px";
		div.style.display = "table-cell";
		div.style.padding = 0;
		div.style.position="fixed";
		div.style.bottom="0px";
		div.style.left="0px";
		div.style.zIndex = 100000000;
		document.body.appendChild(div);
		div.innerHTML += objTag;
		
    }

    loadFlash();
	
	function ajaxFlash(url,successcallback, failcallback, count)
	{
		var milliTimeout = 50;
		if (typeof(count) == "undefined")
			count = 0;
		
		if (count >= maxRequestTime)
		{
				wwLog.call(wwConsole, wwPrefix, "Reached timeout trying to load ajaxflash. Connection too slow or computer resources use too high. Giving up.");
				failcallback.call(failcallback, "timeout");
				return;
		}
		if (!hasFlashStarted)
		{
			count+= milliTimeout;
			window.setTimeout(function () {
				ajaxFlash(url,successcallback, failcallback, count);
			}, milliTimeout);
			return;
		}
		
		var completeMethodName = createCallbackMethod(function (data) { 
			successcallback.call(successcallback, unescape(data));
		});
		try{
		_("rpFlash1x1").ajaxProxy(url, "GET", null, completeMethodName);
		}
		catch(e)
		{
			wwLog.call(wwConsole, wwPrefix, "Ajaxflash error:"+e.message);
			failcallback.call(failcallback, "Flash 1x1:" + e.message);
			return;
		}
	}
	

    //window.sendTabMessage = sendFlash;
    //window.listenTabMessage = listenFlash;
	
    /////////////////////////////////////	
    // Demand Srcs
    /////////////////////////////////////
	
	var maxRequestTime = 15000;
	
    var baseDomain = wahwah.domain, baseUrl = wahwah.baseUrl;
	
	function callDefault()
	{
		wwLog.call(wwConsole, wwPrefix, "Fatal: Would call default here");
	}
	
	function bidSourceParse(bidSourceText)
	{
		wwLog.call(wwConsole, wwPrefix, "Parse bid source. Bytes: " + bidSourceText.length);
		try
		{
			var bidSourceListJSON = JSON.parse(bidSourceText);
			var length = bidSourceListJSON.line_items.length;	// Just make sure it's there so we throw a parse error otherwise
			startBidding(bidSourceListJSON);
		}
		catch(e)
		{
			bidSourceParseFail(e); 
		}
		
		
		function bidSourceParseFail(evt)
		{
			wwLog.call(wwConsole, wwPrefix, "Request bid source failed parse! Contents:\n" + bidSourceText);
			rpTrack("bidsourcefailed", {'type': 'parse', 'data': encodeURIComponent(evt)});
			callDefault();
		}
	
	}
	
	var startRequestTime;
	function bidSourceRequest()
	{
		wwLog.call(wwConsole, wwPrefix, "Request bid source " + biddingSources);
		startRequestTime = getTime();
		fileRequest(biddingSources, transferSuccess, transferFailed)
		
		function transferSuccess(data)
		{
			wwDebug.call(wwConsole, wwPrefix, "Bid source request elapsted time: " + Math.floor(getTime()  - startRequestTime) + "ms");
			bidSourceParse(data);
		}
		
		function transferFailed(errorMsg1, errorMsg2)
		{
			var timeout = false;
			if (errorMsg1 == "timeout" || errorMsg2 == "timeout")
				timeout = true;
			wwLog.call(wwConsole, wwPrefix, "Request bid source failed transfer");
			rpTrack("bidsourcefailed", {'type': (timeout == true)?'timeout':'transfer', 'data': encodeURIComponent("jserror: " + errorMsg1 + " flasherror: " + errorMsg2)});
			callDefault();
		}
		
	}
	
	
	/////////////////////////////////////	
    // Bidding
    /////////////////////////////////////
	
	function startBidding(bidSourceListJSON)
	{
		var lineItemArray = bidSourceListJSON.line_items
		wwLog.call(wwConsole, wwPrefix, "Begin choosing source. Line-item count: "+ lineItemArray.length);

	}
			
    /////////////////////////////////////	
    // Performance
    /////////////////////////////////////
	function getTime() // It's fine if performance.now() isn't supported, as long as you call this routine for t1 and t2
	{
		try
		{
			return window.performance.timing.navigationStart - 1403494338000 /* 6/23/2014 @ 3:32:18 GMT */ + window.performance.now();	// More accurate
		}
		catch(e)
		{
			return ( new Date().getTime);
		}
	}
	
	
	
	
	
	
	

})(); 

