var widgetID = 2978;

var restrictedCountry = false; // rewritten  // If the users are outside of our restricted countries... "BR","CA","DE","ES","GB","US"
var country_code = "US"; // rewritten

/*


 AdOnly 2_6_1




-- Generated Using: Red Panda Platform 3.7.10 (revision: c864f60174f713ad0dd9b17bb946c7802a110960) --

[Product Name: {{ Demo Product Floater }} ]
[Site Name: {{ Demo Product Floater }} ]
[Product id: {{ 449 }} ]
[Widget id: {{ 2978 }} ]

Published on:  2016-04-12 12:59:21 EST
*/

var wahwah = {
    version: "2_6_1",
    branch: "2_6_1",
    environment: "local",
    id: widgetID,
    position: "bottom",
    lan: "EN",
    skin: "default",
    app: "adOnly",
    restrictedCountry: restrictedCountry,
    logLevel: "info",
    debugMode: false,
    loadPreference: "ALWAYS",
    fastLoad: true,
    adconfig: {
        "inpage": {
            "enabled": false,
            "adSize": 300,
            "vidWidth": 558,
            "vidHeight": 314,
            "displayWidth": 300,
            "displayHeight": 250,
            "bannerAdsPerVideoAd": 4,
            "freqCap": false,
            "freqNum": 2,
            "combinedDisplayURL": "ww-openx:auid=538464608;", //538464608 538464632
            "combinedDisplayLBURL": "",
            "displayURL": "ww-openx:auid=538376280;",
            "displayLBURL": "",
            "mobile320URL": "ww-openx:auid=538376283;",
            "mobile728URL": "ww-openx:auid=538376282;",
            "leaveBehindAdURL": "ww-openx:auid=538376284;",
            "adFormat": "wallpaper",
            /* The following affect page position */
            "floatVertPos": "bottom",
            "floatHorizPos": "center",
            /* The following affect expansion direction. */
            "inPageAlignment": "right", /* deprecated. Use expansionAlignHoriz instead */
            "expansionAlignHoriz": "center",
            "expansionAlignVert": "bottom",
            "inAdBreakout": false,
            "outstreamAutoload": false,
            "outstreamTriggerId": "wahwahAd",
            "outstreamFloat": false,
            "vidURL": "http://test.wahwahnetworks.com/david/vast.xml", //http://ox-d.wahwahnetworks.com/v/1.0/av?auid=538376281
            "secondsBetweenBanners": 615,
            "perSessionCap": 15,
            "secondsToExpand": 15,
            "vidCountdownNumFormat": "${SEC}",
            "audioVolume": 0
        },
        "interstitial": {
            "enabled": false,
            "freqCap": false,
            "freqNum": 2
        },
        "linear": {
            "enabled": false
        }
    }
};


if (typeof(RP_PUBLISHER_KEYS) != "undefined")
{
    var WAHWAH_PUBLISHER_KEYS = RP_PUBLISHER_KEYS;
}

// Client Features Object
wahwah.clientFeatures = {};



if(typeof document.currentScript != "undefined"){
    wahwah.currentScript = document.currentScript;
}

// Used to make sure multiple versions don't conflict with each other
if (typeof(wahwahObjs) == 'undefined') { wahwahObjs = []; }
wahwahObjs[wahwahObjs.length] = wahwah;

(function () {

    var wahwah = window.wahwah;
    var tbPath = "00BA6A/product/_release";
    var domain = "http://cdn-s.wwnstatic.com";

    switch (wahwah.environment) {
        case "local":
        case "local_www":
            wahwah["domain"] = "*";
            wahwah["baseUrl"] = window.location.href.substring(0,window.location.href.lastIndexOf("/"))+ "/";
            break;
        case "dev":
        case "qa":
        case "prod":
            wahwah["domain"] = domain;
            wahwah["baseUrl"] = domain + "/" + tbPath + "/" + wahwah.environment + "/" + wahwah.version + "/";

            if(wahwah.debugMode){
                wahwah.baseUrl += "_original/";
            }

            break;
        default:
            console.log("*** WW warning: wahwah.environment set incorrectly");
    }

    if (document.readyState === "complete" || document.readyState === "interactive")
    {
        // In this case, loader.js will use DOM manipulations
        var fileref = document.createElement('script');
        fileref.setAttribute("type","text/javascript");
        fileref.setAttribute("src", wahwah.baseUrl + "widget/loader.js");
        document.getElementsByTagName("head")[0].appendChild(fileref);
    } else {
        document.writeln('<scr'+'ipt src="'+wahwah.baseUrl + "widget/loader.js"+'" type="text/javascript"></scr'+'ipt>');
    }
})();