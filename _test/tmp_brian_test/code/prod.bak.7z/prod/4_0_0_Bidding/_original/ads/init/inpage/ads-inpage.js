

var AdType = {
    DISPLAY_AD: "Display",
    VIDEO_AD: "Video"
};

var adExpanded = false;
var successfullyLoaded = false;
var currentAdType = null;
var transitionEnd = whichTransitionEvent();
var bannerCount = 0;
var totalCount = 0;
var displayTimeout = -1;
var collapseTimeout = -1;
var inpageVideoAdsDisabled = false;
var currentPlacement = null;
var ivdoAd = false;

var combinedVideoURL = null;

var adContainer;
var adModule;

if (typeof console == "undefined")
{
    var console = {};
    wwLog = function () { };
}

wwDebug.call(wwConsole, wwPrefix, "ads-inpage ts=" + getTime());

function expandAd()
{
	adExpanded = true;
	

	if (currentAdType == "Video") {

		adContainer.style.width = adConfig.inpage.vidWidth + 15 +"px"; // Added 15px overhang for close button
		adContainer.style.height = adConfig.inpage.vidHeight + 15 + "px"; // Added 15px overhang for close button
		adModule.style.height = adConfig.inpage.vidHeight + 15 + "px"; // Added 15px overhang for close button
		adModule.style.width = adConfig.inpage.vidWidth + 15 + "px"; // Added 15px overhang for close button

	} else if (currentAdType == "Display") {

		// DC - Only need to call this for Display Ads
		sendMessage("expandAd", ModuleEnums.MODULE_LOADER, {"inpageType" : currentAdType});

		switch (displayType) {
	        case "desktopDisplay":
	        	adModule.style.height = adConfig.inpage.displayHeight + 27 + "px";
	        	adContainer.style.width = adConfig.inpage.displayWidth + "px";
				adContainer.style.height = adConfig.inpage.displayHeight + "px";
	            break;
	        case "tabletDisplay":
	            wwDebug.call(wwConsole, wwPrefix, 'Tablet Display');
	            adModule.style.height = 90  + "px";
				//close.style.display = "block";
				adContainer.style.width = 728 + "px";
				adContainer.style.height = 90 + "px";
	            break;
	        case "mobileDisplay":
	            adContainer.style.marginLeft = 7 + "px";
	            adModule.style.height = 50  + "px";
				//close.style.display = "block";
				adContainer.style.width = 320 + "px";
				adContainer.style.height = 50 + "px";
	            break;	
	    }

	    adModule.className = "expand";

	}	

	adContainer.style.overflow = "visible";
	
	// temp hack until replay at end of video ad is supported in video player
	// if video ad has completed, load next ad
	if (currentAdType == "")
		loadInpageAd();
}

function clearCollapse() {
	if (collapseTimeout != -1)
 	{
		clearTimeout(collapseTimeout);
		collapseTimeout = -1;
	}

	if (displayTimeout != -1)
 	{
  		clearTimeout(displayTimeout);
  		displayTimeout = -1;
 	}
}

function playToggle() {
	wwDebug.call(wwConsole, wwPrefix, 'playToggle in Ad')
}

function audioToggle() {
	wwDebug.call(wwConsole, wwPrefix, 'audioToggle in Ad')
}

function replayVideo() {
	wwDebug.call(wwConsole, wwPrefix, 'replayVideo Toggle')
	window.clearTimeout(handleCollapseTimeout);
	collapseTimeout = window.setTimeout(handleCollapseTimeout, 240000); // Make sure that if user replays a lot, that ad isn't killed prematurely
}


function startLoad_inpage() 
{
	wwLog.call(wwConsole, wwPrefix, "Ad module - Inpage loaded.");
	wwDebug.call(wwConsole, wwPrefix, "inpage.startLoad_inpage ts=" + getTime());

	adContainer = document.getElementById("adContainer");
	adModule = document.getElementById("adModule");
	//close = document.getElementById("close");

	
	if (typeof(adConfig.inpage.displayURL) == "undefined")
		adConfig.inpage.displayURL = "";
	if (typeof(adConfig.inpage.vidURL) == "undefined")
		adConfig.inpage.vidURL = "";
	
	// Shouldn't get here. Catch in loader instead. Just in case
	if (adConfig.inpage.enabled == false)
	{
		wwLog.call(wwConsole, wwPrefix, "Inpage disabled.");
		return;
	}
	
	bannerCount =  adConfig.inpage.bannerAdsPerVideoAd + 1;	// Force video to load first. Covers case where combinedDisplayURL is ""
	
	var width = adConfig.inpage.width;
	var height = adConfig.inpage.height;

	adContainer.style.width = width + "px";
	adContainer.style.height = height + "px";
	adContainer.style.left = (300 - width)/2 + "px";

	loadInpageAd();
	
}

function loadInpageAd()
{
	if (inpageVideoAdsDisabled)
		return;
	if (totalCount > adConfig.inpage.perSessionCap)
		return;
		
	if (displayTimeout != -1) // After a successful video ad
	{
		clearTimeout(displayTimeout);
		displayTimeout = -1;
	}
	if (collapseTimeout != -1)
	{
		clearTimeout(collapseTimeout);
		collapseTimeout = -1;
	}

	successfullyLoaded = false;
	
	var lan = wahwah.lan;

	// Only check for a video if it's NOT a mobileDisplay - "M or B at the end of string"
	if (adConfig.inpage.combinedDisplayURL == "" && getShouldShowVideoAd()&&(placementType.slice(-1) != "M")&&(placementType.slice(-1) != "B"))
	{

		// Show video ad
		currentAdType = AdType.VIDEO_AD;
		
		wwDebug.call(wwConsole, wwPrefix, "inpage.loadInpage/AdType.VIDEO_AD ts=" + getTime());

		if (combinedVideoURL != null)
		{

			wwForceLog.call(wwConsole, wwPrefix, "Combined video call detected - displaying...");
			adConfig.inpage.vidURL = combinedVideoURL;
		}
		else
		{
			wwForceLog.call(wwConsole, wwPrefix, "Checking for backup video ad.");
			if (adConfig.inpage.vidURL == "")
			{	
				wwForceLog.call(wwConsole, wwPrefix, "Inpage: No video ad provided.");
				loadInpageAd();
				return;
			}
			
		}
		
		var wBufferHeight = adConfig.inpage.vidHeight + 15;
		var wBufferWidth = adConfig.inpage.vidWidth + 15;
		var html = '<!DOCTYPE html><html><head><base href="${WAHWAHROOT}ads/adcontainers/videoad/"><title>wahwah adframe</title><link rel="stylesheet" type="text/css" href="${WAHWAHROOT}ads/adcontainers/videoad/vidplayerframe.css" /></head><body><scr'+'ipt type="text/javascr'+'ipt" src="${WAHWAHROOT}ads/adcontainers/videoad/vidplayerframe.js"></scr'+'ipt></body></html>';
		/*
		document.getElementById("adContainer").innerHTML = '<ifr'+'ame style="overflow: hidden; background-color: transparent; border:0; width:'+ wBufferWidth +'px; height:'+ wBufferHeight +'px" src="./adcontainers/videoad/vidplayerframe.html'+window.location.hash.split("?")[0]+'?adType=inpage&adconfig=' + encodeURIComponent(JSON.stringify(adConfig))+'"></ifr'+'ame>';*/
		var vars = {
			"friendlyAdFrameId": "inpageVidPlayerFrame",
			"friendlyAdFrameConfig": adConfig,
			"friendlyAdFrameType": "inpage",
			"friendlyAdFrameLang" : lan,
			"friendlyAdFrameUABrowser": uaBrowser,
			"friendlyAdFrameReferrerMacro": referrer,
			"friendlyAdFrameDomainMacro": domain,
			"friendlyAdFramePlacementId": placementId
		};

		sendMessage("createFriendlyIframe", ModuleEnums.MODULE_LOADER, {"width" : wBufferWidth, "height": wBufferHeight, "html": html, "id": vars["friendlyAdFrameId"], "vars": vars, "isVideo": true});
		collapseTimeout = window.setTimeout(handleCollapseTimeout, 240000); // Typically, player contracts on end of video. Prevent stalled player (bad connection, etc) from preventing display ad for more than 4 seconds (video ads should be shorter than this)
	}
	else
	{
		
		currentAdType = AdType.DISPLAY_AD;
		
		wwDebug.call(wwConsole, wwPrefix, "inpage.loadInpage/AdType.DISPLAY_AD ts=" + getTime());
		
		if (adConfig.inpage.combinedDisplayURL == "")
		{
			wwForceLog.call(wwConsole, wwPrefix, "Calling backup display ad...");
		}
		
		if (adConfig.inpage.displayURL == "")
		{
			wwForceLog.call(wwConsole, wwPrefix, "Inpage: No display ad provided (possibly intentional)");
			return;
		}
		
		var html = '<!DOCTYPE html><html><head><base href="${WAHWAHROOT}ads/adcontainers/display/"><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0,maximum-scale=1.0, user-scalable=0"/><title>wahwah adframe</title></head><body style="margin: 0px 0px 0px 0px; overflow: hidden; background-color: transparent;" ><scr'+'ipt type="text/javascr'+'ipt" src="${WAHWAHROOT}ads/adcontainers/display/displayadframe.js"></scr'+'ipt></body></html>';
		if (placementType.slice(-1) == "M") 
		{	
			if (displayType == "mobileDisplay") { 
				/*document.getElementById("adContainer").innerHTML = '<ifr'+'ame style="overflow: hidden; background-color: transparent; border:0; width:'+320+'px; height:'+50+'px" src="./adcontainers/display/displayadframe.html'+window.location.hash.split("?")[0]+'?displayType=' + displayType + '&placementType=' + placementType + '&adType=inpage&adconfig=' + encodeURIComponent(JSON.stringify(adConfig))+'"></ifr'+'ame>';*/
				
				if (placementType == "300M") {
					var vars = {
					"friendlyAdFrameId": "300x250",
					"friendlyAdFrameConfig": adConfig,
					"friendlyAdFramePlacementType": placementType,
					"friendlyAdFrameDisplayType": displayType,
					"friendlyAdFrameLang" : lan,
					"friendlyAdFrameType": "inpage"
				};
				sendMessage("createFriendlyIframe", ModuleEnums.MODULE_LOADER, {"width" : 300, "height": 250, "html": html, "id": vars["friendlyAdFrameId"], "vars": vars, "isVideo" : false});
				} else {
					var vars = {
					"friendlyAdFrameId": "320x50",
					"friendlyAdFrameConfig": adConfig,
					"friendlyAdFramePlacementType": placementType,
					"friendlyAdFrameDisplayType": displayType,
					"friendlyAdFrameLang" : lan,
					"friendlyAdFrameType": "inpage"
				};
				sendMessage("createFriendlyIframe", ModuleEnums.MODULE_LOADER, {"width" : 320, "height": 50, "html": html, "id": vars["friendlyAdFrameId"], "vars": vars, "isVideo" : false});
				}
				
			} else {
			/*
				document.getElementById("adContainer").innerHTML = '<ifr'+'ame style="overflow: hidden; background-color: transparent; border:0; width:'+728+'px; height:'+90+'px" src="./adcontainers/display/displayadframe.html'+window.location.hash.split("?")[0]+'?displayType=' + displayType + '&placementType=' + placementType + '&adType=inpage&adconfig=' + encodeURIComponent(JSON.stringify(adConfig))+'"></ifr'+'ame>';*/
				var vars = {
				"friendlyAdFrameId": "728x90",
				"friendlyAdFrameConfig": adConfig,
				"friendlyAdFramePlacementType": placementType,
				"friendlyAdFrameDisplayType": displayType,
				"friendlyAdFrameType": "inpage"
				};
				sendMessage("createFriendlyIframe", ModuleEnums.MODULE_LOADER, {"width" : 728, "height": 90, "html": html, "id": vars["friendlyAdFrameId"], "vars": vars, "isVideo" : false});
			}
		} else {
		/*
			document.getElementById("adContainer").innerHTML = '<ifr'+'ame style="overflow: hidden; background-color: transparent; border:0; width:'+adConfig.inpage.displayWidth+'px; height:'+adConfig.inpage.displayHeight+'px" src="./adcontainers/display/displayadframe.html'+window.location.hash.split("?")[0]+'?displayType=' + displayType + '&placementType=' + placementType + '&adType=inpage&adconfig=' + encodeURIComponent(JSON.stringify(adConfig))+'"></ifr'+'ame>';
			*/
			
			if (adConfig.inpage.combinedDisplayURL == "" && adConfig.inpage.displayURL == "")
			{
				wwForceLog.call(wwConsole, wwPrefix, "Inpage: No display ad provided (possibly intentional)");
				return;
			} 
			
			// If it's a display ad we want to keep the ad expanded and not call the timeout.
			//if (!adOnly) { 
				//collapseTimeout = window.setTimeout(handleCollapseTimeout, adConfig.inpage.secondsToExpand*1000);
			//}

			var vars = {
				"friendlyAdFrameId": "" + adConfig.inpage.displayWidth + "x" + adConfig.inpage.displayHeight,
				"friendlyAdFrameConfig": adConfig,
				"friendlyAdFramePlacementType": placementType,
				"friendlyAdFrameDisplayType": displayType,
				"friendlyAdFrameType": "inpage",
				"friendlyAdReloaded": false
				};

			if (adReloaded) {
				vars["friendlyAdReloaded"] = true;
			}

			sendMessage("createFriendlyIframe", ModuleEnums.MODULE_LOADER, {"width" : adConfig.inpage.displayWidth, "height": adConfig.inpage.displayHeight, "html": html, "id": vars["friendlyAdFrameId"], "vars": vars, "isVideo": false});
		}

	}

	//displayTimeout = window.setTimeout(handleAdTimeout, adConfig.inpage.secondsBetweenBanners*1000);
	totalCount++;

}

function handleAdTimeout()
{
	displayTimeout = -1;
	loadInpageAd();
}

function handleCollapseTimeout()
{
	collapseTimeout = -1;
	//collapseAd();
}

function onVideoCompleted() // called by vidplayerframe
{
	clearTimeout(collapseTimeout);
	collapseTimeout = -1;
	currentAdType = "";
	if (successfullyLoaded) {
		combinedVideoURL = null;
		// Don't know whether this is a Combined video or a BackUp Video - DC
		wwLog.call(wwConsole, wwPrefix, "Video ended successfully.");
		sendMessage("removeFriendlyIframe", ModuleEnums.MODULE_LOADER, {"src": "onVideoCompleted"});
		//collapseAd();
	} else
	{
		wwLog.call(wwConsole, wwPrefix, "Video: UIF reports ad as completed, but had never started. Probably a VPAID error.");
		onVideoError(); // Never actually successfully loaded
	}
}

function onVideoError() // called by vidplayerframe
{
	wwDebug.call(wwConsole, wwPrefix, 'onVideoError');
	sendMessage("removeFriendlyIframe", ModuleEnums.MODULE_LOADER, {"src": "onVideoError"});
	//collapseTimeout = 15;
	if (combinedVideoURL == null)
	{
		loadInpageAd();
	}
	else
	{
		wwForceLog.call(wwConsole, wwPrefix, "Combined video error. Making backup calls");
		combinedVideoURL = null;
		bannerCount =  adConfig.inpage.bannerAdsPerVideoAd + 1;	// Force video to load first
		adConfig.inpage.combinedDisplayURL = "";
		loadInpageAd();
	}
}

function onDisplayError() // called by displayadframe
{
	clearTimeout(collapseTimeout);
	collapseTimeout = -1;
	currentAdType = "";
	// Don't collapse ad here, since it never expanded
	sendMessage("removeFriendlyIframe", ModuleEnums.MODULE_LOADER, {"src": "onDisplayError"});
    adExpanded = false;
    // Adding the adReloaded variable so the unit doesn't continuously loop
	if ((adConfig.inpage.combinedDisplayURL != "")&&(!adReloaded))
	{
		wwForceLog.call(wwConsole, wwPrefix, "Combined display url empty or invalid. Making backup calls");
		bannerCount =  adConfig.inpage.bannerAdsPerVideoAd + 1;	// Force video to load first
		adConfig.inpage.combinedDisplayURL = "";
		loadInpageAd();
	}
	else
	{
		sendMessage("noAdsFound", ModuleEnums.MODULE_LOADER, {"src": "onDisplayError"});
	}
}

function onSuccessfulLoad(customCampaign, customCampaignName, isVideo)
{
	successfullyLoaded = true;

	// Loads the Toolbar and the Radio only if the preference is 'ONLY_IF_AD_SHOWS'
	// Otherwise these 2 options will load twice								
		// Also making sure it's not a 'passback'
	if (customCampaignName != "passback") /*(customCampaignName != "myspace")&&*/ // if it's a myspace campaign we need to wait to make sure they serve an ad first
		sendMessage("adLoaded", ModuleEnums.MODULE_LOADER, {"customCampaign": true, "customCampaignName": customCampaignName, "isVideo": isVideo });	// Don't load the toolbar until after an ad has successfully loaded

	if (!customCampaign)
		expandAd();
}

function getShouldShowVideoAd()
{
	/*if (uaBrowser == "Chrome" || uaBrowser == "Safari") // Safari blocks Flash due to power saver mode. Temp disable Chrome video ads as well. Chrome currently has low video ad requests for some reason
	{
		wwDebug.call(wwConsole, wwPrefix, "Video: Not showing video ad for " + uaBrowser); 
		return false;
	}*/
	if (combinedVideoURL != null)
		return true;
	if (!inpageVideoAdsDisabled && bannerCount >=  adConfig.inpage.bannerAdsPerVideoAd)
	{
		bannerCount = 0;
		return true;
	}
	bannerCount++;
	return false;
}

function handleMessage_inpage(evt)
{
    if (!evt) evt = window.event;
	
	try {
		var messageObj = JSON.parse(evt.data);
	} catch(e) {
		return;
	}

	if (messageObj.type == "combinedVideo") 
	{
        wwDebug.call(wwConsole, wwPrefix, "Message : combinedVideo");
		adConfig.inpage.combinedDisplayURL = "";
		combinedVideoURL = messageObj.content.vidURL;
		loadInpageAd();
    }
}


function whichTransitionEvent(){
    var t;
    var el = document.createElement('fakeelement');
    var transitions = {
      'transition':'transitionend',
      'OTransition':'oTransitionEnd',
      'MozTransition':'transitionend',
      'WebkitTransition':'webkitTransitionEnd'
    }

    for(t in transitions){
        if( el.style[t] !== undefined ){
            return transitions[t];
        }
    }
}


// Performance
function getTime() // It's fine if performance.now() isn't supported, as long as you call this routine for t1 and t2
{
	try
	{
		return window.performance.timing.navigationStart - 1403494338000 /* 6/23/2014 @ 3:32:18 GMT */ + window.performance.now();	// More accurate
	}
	catch(e)
	{
		return ( new Date().getTime);
	}
}
