
if (typeof console == "undefined")
{
    var console = {};
    wwLog = function () { };
}

var wahwah = parent.wahwah;

var id = wahwah.iframeVars.friendlyAdFramePlacementId;
var fifId = wahwah.iframeVars.friendlyAdFrameId;
var adConfig = wahwah.iframeVars.friendlyAdFrameConfig;
var adType = wahwah.iframeVars.friendlyAdFrameType;
var tbBase = wahwah.iframeVars.friendlyAdFrameBase;
var adBase = tbBase+"ads/adcontainers/videoad/";
var uaBrowser = wahwah.iframeVars.friendlyAdFrameUABrowser;
var clientFeatures = wahwah.clientFeatures;
var referrer = parent.wahwah.iframeVars.friendlyAdFrameReferrerMacro;
var domain = parent.wahwah.iframeVars.friendlyAdFrameDomainMacro;

var customPubReportVals = "";
if (clientFeatures.hasOwnProperty("customPublisherReportKeyValues"))
{
	var customPubReportVals = JSON.stringify(clientFeatures["customPublisherReportKeyValues"]);
	// Macros
	customPubReportVals = customPubReportVals.replace(/\$\$/g,"${$}");
	customPubReportVals = customPubReportVals.replace(/\$\{REFERRER\}/gi,encodeURIComponent(referrer));
	customPubReportVals = customPubReportVals.replace(/\$\{DOMAIN\}/gi,encodeURIComponent(domain));
	customPubReportVals = customPubReportVals.replace(/\$\{\$\}/g,"$");
	openxPubCustom="&c.pub_custom="+encodeURIComponent(customPubReportVals);
}

// Start WW tracking
var imgArray = [];

function addImage(img){
	var current = imgArray.length;
	imgArray[current] = document.createElement("img");
	imgArray[current].setAttribute("src", img);
}


if (!Date.now) {
	Date.now = function() { return new Date().getTime(); }
}
// End WW tracking shared

var persistantClose = false;
if (wahwah.app == "adOnly")
{
	if (adConfig[adType].floater == true || adConfig[adType].vidWidth > adConfig[adType].displayWidth || adConfig[adType].vidHeight > adConfig[adType].displayHeight)
		persistantClose = true;
}

var hostaudio = false;
var audioVolume = 0;

var ModuleEnums = {
MODULE_LOADER: "Loader",
MODULE_TOOLBAR: "Toolbar",
MODULE_RADIO: "Radio",
MODULE_ADS: "Ads"
};


/* Avoid `console` errors in browsers that lack a console. Modified based on: http://html5boilerplate.com/ */ (function() { var method; var noop = function () {}; var methods = ['debug','error','info', 'log','warn']; var length = methods.length; var console = (window.console = window.console || {}); while (length--) { method = methods[length]; /* Only stub undefined methods. */ if (!console[method]) { console[method] = noop; } } }()); /* First, check if IE running in Quirks mode, which treats window.console.log as an object, not ECMAScript function, and doesn't support .call on that object */ if (typeof(window.console.log.call) != "function") { console.warn("[Wahwah] This debugger doesn't support console.* as a function / console.log.call, etc. Possibly IE in Quirks/Compatibility mode or Firebug. View on web or localhost (not local or intranet) and in HTML5 or use a debug toolbar that supports console.* as a true ECMAScript function.");  /* Next, create console.log placeholder if it doesn't exist */	window.console = { 	debug : function() {}, 	error: function() {}, info: function() {}, 	log: function() {}, warn: function() {} }; }; /* Create addListener placeholder, when it doesn't exist */ var addListener = function (e, t, n) { if ("addEventListener" in e) { e.addEventListener(t, n, true) } else if ("attachEvent" in e) { var r = function () { n(window.event) }; e.attachEvent("on" + t, r) } }; var removeListener = function (e, t, n) { if ("removeEventListener" in e) { e.removeEventListener(t, n, true) } else if ("detachEvent" in e) { var r = function () { n(window.event) }; e.detachEvent("on" + t, r) } }

// Todo: Pass up the parent window chain when possible
// Later, replace with htm5 BroadcastChannel message when all browsers support to decrease size
if (typeof(window.wwMsg) == "undefined")
{
	window.wwMsg = new function() {
		this._module = "Video Ads";
		this._prefix = function(module)
		{
			if (module == null)
			{
				module = this._module;
			}
			return "[Wahwah " + module + "] ";
		}
		this._debugLevelInt = function()
		{
			switch(wahwah.logLevel)
			{
				case "debug":
					return 3;
					break;
				case "info":
					return 2;
					break;
				case "warn":
					return 1;
					break;
				case "error":
					return 0;
					break;
				default:
					return 0;
			}
		}
		this.forceLogProto = function()
		{
			return console.log;
		}
		this.errorProto = function()
		{
			if (this._debugLevelInt() >= 0)
				return console.error;
			else
				return (function () {})
		}
		this.warnProto = function()
		{
			if (this._debugLevelInt() >= 1)
				return console.warn;
			else
				return (function () {})
		}
		this.logProto = function()
		{
			if (this._debugLevelInt() >= 2)
				return console.log;
			else
				return (function () {})
		}
		this.debugProto = function()
		{
			if (this._debugLevelInt() >= 3)
				return console.debug;
			else
				return (function () {})
		}
		this.infoProto = function() {return this.logProto()}


	}

		// easier minification
		var wwConsole = window.console;
		var wwPrefix = window.wwMsg._prefix(null);
		var wwLog = window.wwMsg.logProto();
		var wwWarn = window.wwMsg.warnProto();
		var wwDebug = window.wwMsg.debugProto();
		var wwError = window.wwMsg.errorProto();
		var wwInfo = window.wwMsg.infoProto();
		var wwForceLog = window.wwMsg.forceLogProto(); // Use sparingly
}


wwLog.call(wwConsole, wwPrefix, "~~~~~~~~vidplayerframe.js");
wwDebug.call(wwConsole, wwPrefix, "vidplayerframe ts=" + getTime());

var addListener = function (obj, event, handler)
{
    if (typeof addEventListener != "undefined")
    {
        obj.addEventListener(event, handler, true);
    } else if (typeof attachEvent != "undefined")
    {
        var newHandler = function ()
        {
            handler(window.event);
        };

        obj.attachEvent("on" + event, newHandler);
    }
};

var removeListener = function (obj, event, handler)
{
    if (typeof removeEventListener != "undefined")
    {
        obj.removeEventListener(event, handler, true);
    } else if (typeof detachEvent != "undefined")
    {
        var newHandler = function ()
        {
            handler(window.event);
        };

        obj.detachEvent("on" + event, newHandler);
    }
};



var adCall = adConfig[adType].vidURL;
var width = adConfig[adType].width;
var height = Math.floor(width *  9/16);

function startLoad()
{

	wwLog.call(wwConsole, wwPrefix, "vidplayerframe.startLoad ts=" + getTime());

	// Track start ad request
	addImage(tbBase+"ww.gif?event=vrequest&uid="+fifId+"&ts="+Date.now());

	addListener(window, "message", handleMessage);
	removeListener(document, "DOMContentLoaded", startLoad);
	removeListener(window, "load", startLoad);

	//addListener(document.getElementById("play_toggle"), "mouseup", playpauseclick);
	//addListener(document.getElementById("audio_toggle"), "mouseup", muteunmuteclick);
	addListener(document.getElementById("replay_video"), "mouseup", replayclick);
	addListener(document.getElementById("vidPlayback"), "mouseenter", adOver);
	//addListener(document.getElementById("close"), "mouseenter", closeOver);


	if (adType == "interstitial")
	{
		// Remove element otherwise lang will write to it
		document.getElementById("countdown").style.display = "none";
	}





	// =================================================================
	// Start display
	if (adCall.indexOf('ox-d.wahwahnetworks.com/v/1.0') != -1)
		xmlTag = adCall + '&cc=1&md=1';  // OX fix needed for Safari to make XML Request
	else
		xmlTag = adCall;

	wwLog.call(wwConsole, wwPrefix, "xmlTag = " + xmlTag);
	xmlTag = replaceWildcardWithCacheBuster(xmlTag);
	queryVAST(xmlTag, "N/A", onQVSuccess, onQVFailure, null );

}

var vidPaused = false;
var audMuted = true;
var successfulLoad = false;
var closeAvailable = false;
function eiShowPlaying (play)
{
	wwLog.call(wwConsole, wwPrefix, "~~~ eiShowPlaying " + play);

	document.getElementById("vidPlayback").className = "show";
	vidPaused = !play;
	if (vidPaused == false)
	{
		// Chrome was having a bug where it was using the background color of vidPlayback to affect alpha of the player
		document.getElementById("vidPlayback").style.backgroundColor = "white"; // Hack for Chrome
		if (successfulLoad == false) // Only call onAdSuccessfulLoad once
		{
			successfulLoad = true;
			addImage(tbBase+"ww.gif?event=vstart&uid="+fifId+"&ts="+Date.now());
			sendMessage("onAdSuccessfulLoad", ModuleEnums.MODULE_LOADER, {"customCampaign": false, "customCampaignName": "", "isVideo": true });

			//document.getElementById("wahwahadplayer").eiPauseClick();

			window.clearTimeout(callTimer);
			wwLog.call(wwConsole, wwPrefix, "Stopped Timer");
		}
/*
		if (persistantClose)
		{
			if (document.getElementById("close"))
				document.getElementById("close").className = "show";
		}*/
		// Show play button, etc
		//document.getElementById("videoControls").style.visibility = "visible";
		//document.getElementById("replay_video").style.visibility = "visible";
		//document.getElementById("play_toggle").childNodes[0].src = './images/pause.png';
	}
	else
	{
		//document.getElementById("play_toggle").childNodes[0].src = './images/play.png';
	}

}
function eiShowMuted (muted)
{
	audMuted = muted;
	if (audMuted == true)
	{
		// Show audio toggle muted
		//document.getElementById("audio_toggle").innerHTML = "AUDON";
		document.getElementById("audio_toggle").childNodes[0].src = './images/audio_on.png';

	}
	else
	{
		//document.getElementById("audio_toggle").innerHTML = "AUDOFF";
		document.getElementById("audio_toggle").childNodes[0].src = './images/audio_off.png';
	}
}

function eiAdCompleted ()
{
	// Chrome was having a bug where it was using the background color of vidPlayback to affect alpha of the player
	document.getElementById("vidPlayback").style.backgroundColor = "transparent"; // Hack for Chrome; change back
	removeListener(vidPlayback, "mouseenter", adOver);
	removeListener(document.getElementById("replay_video"), "mouseup", replayclick);
	//removeListener(document.getElementById("close"), "mouseover", closeOver);
	wwDebug.call(wwConsole, wwPrefix, "vidplayerframe.eiAdCompleted ts=" + getTime());
	wwForceLog.call(wwConsole, wwPrefix, "Video ad play completed");
	addImage(tbBase+"ww.gif?event=vcomplete"+"&uid="+fifId+"&ts="+Date.now());
	sendMessage("onAdVideoPlayerComplete", ModuleEnums.MODULE_LOADER,"");
}

function eiAdError ()
{
	wwDebug.call(wwConsole, wwPrefix, "vidplayerframe.eiAdError ts=" + getTime());
	wwForceLog.call(wwConsole, wwPrefix, "Video error: Invalid tag or other error ");
	addImage(tbBase+"ww.gif?event=verror&error=invalid"+"&uid="+fifId+"&ts="+Date.now());
	sendMessage("onAdVideoPlayerError", ModuleEnums.MODULE_LOADER, "");
}


function eiCountdown(remaining, duration)
{
	window.setTimeout('updateCountdown('+remaining+','+duration+')',10);
}

/*
Macros for adConfig.*.vidCountdownNumFormat
${MM} remaining minutes for time in MM:SS format
${SS} remaining seconds for time in MM:SS format
${TMM} total minutes for time in MM:SS format
${TSS} total seconds for time in MM:SS format
${SEC} remaining seconds (where time is in only seconds)
${TSEC} total seconds (where time is in only seconds)
Example:
If there is 1 minute, 5 seconds left
${MM} = 1
${SS} = 05
${SEC} = 65
*/
function updateCountdown(remaining, duration)
{
	if (remaining < 0)
		remaining = 0;
	var countdownText = adConfig[adType].vidCountdownNumFormat;
	var remainMM = Math.floor(remaining/60);
	var totalMM = Math.floor(duration/60);
	var remainSS = Math.floor(remaining - remainMM*60);
	var totalSS = Math.floor(duration - totalMM*60);
	var timeDiff = duration - remaining; // Display close button only after user has seen :15 seconds of the video
	countdownText = countdownText.replace("${MM}",remainMM);
	countdownText = countdownText.replace("${SS}",(remainSS >= 10)?remainSS : "0" + remainSS);
	countdownText = countdownText.replace("${TMM}",totalMM);
	countdownText = countdownText.replace("${TSS}",(totalSS >= 10)?totalSS : "0" + totalSS);
	countdownText = countdownText.replace("${SEC}",Math.floor(remaining));
	countdownText = countdownText.replace("${TSEC}",Math.floor(duration));
	if (adType == "interstitial")
	{
		// Handle interstitial countdowns in the parent
		sendMessage("onUpdateCountdown", ModuleEnums.MODULE_LOADER,
			{
				"remaining": remaining,
				"duration": duration
			}
		);
		return;
	}
	else {

		/*if ((timeDiff >= 15)&(remaining!=0))  // sometimes the remaining comes up as 0 which causes timeDiff to hit 30
			closeAvailable = true; */
		//document.getElementById("countdown_counter").innerHTML = countdownText;
	}

}

function  playpauseclick()
{
// Todo: Make this also work for html5, however for now this shouldn't be called in toolbar/adonly
	if (vidPaused)
		document.getElementById("wahwahadplayer").eiPlayClick();
	else
		document.getElementById("wahwahadplayer").eiPauseClick();
}

function  muteunmuteclick()
{
// Todo: Make this also work for html5, however for now this shouldn't be called in toolbar/adonly
	if (audMuted)
		document.getElementById("wahwahadplayer").eiUnMuteClick();
	else
		document.getElementById("wahwahadplayer").eiMuteClick();
}

function  replayclick()
{
	if (chosenAdTechnology == "flash")
	{
		document.getElementById("wahwahadplayer").eiUnMuteClick(); // Because replay doesn't actually turn on volume
		document.getElementById("wahwahadplayer").eiReplayClick();
	}
	else
	{

		html5Player.muted(false);
		html5Player.ima.getAdsManager().setVolume(1.0);
		/* Can't figure out how to seek properly  **
		html5Player.ima.getAdsManager().pause();
		html5Player.currentTime(0);
		html5Player.ima.getAdsManager().resume();
		*/
	}

	document.getElementById("replay_video").style.visibility = "hidden";
}

function adOver()
{
	//removeListener(vidPlayback, "mouseenter", adOver);
	document.getElementById("replay_video").className = "show";
	addListener(document.getElementById("replay_video"), "mouseenter", replayOver);
	addListener(document.getElementById("vidPlayback"), "mouseleave", adOut);

	/*if (!persistantClose)
		document.getElementById("close").className = "show";*/

}

function adOut()
{
	//removeListener(vidPlayback, "mouseenter", adOut);
	document.getElementById("replay_video").className = "";
	/*if (!persistantClose)
		document.getElementById("close").className = "";*/
	addListener(document.getElementById("vidPlayback"), "mouseenter", adOver);
}

function replayOver()
{
	removeListener(replay_video, "mouseenter", replayOver);
	document.getElementById("replay_video").className = "over";
	addListener(document.getElementById("replay_video"), "mouseleave", replayOut);
}

function replayOut()
{
	removeListener(replay_video, "mouseenter", replayOut);
	document.getElementById("replay_video").className = "show";
	addListener(document.getElementById("replay_video"), "mouseenter", replayOver);
}

function closeOver() {
	removeListener(vidPlayback, "mouseenter", adOut);
	//removeListener(document.getElementById("close"), "mouseenter", replayOut);
	//addListener(document.getElementById("close"), "mouseup", function(e) {
		if (chosenAdTechnology == "flash")
		{
			// Temporary Fix for Chrome
			document.getElementById("wahwahadplayer").eiMuteClick();
			// End Temp Fix
		}
		else
		{
			html5Player.muted(true); // Probably overkill
			html5Player.ima.getAdsManager().setVolume(1.0); // Probably overkill
			html5Player.ima.getAdsManager().stop(); // Important (tracking, etc)
		}

		sendMessage("videoClosed", ModuleEnums.MODULE_LOADER,"");

}


function handleMessage(evt)
{
	if (!evt) evt = window.event;

	try {
		var messageObj = JSON.parse(evt.data);
	} catch(e) {
		return;
	}

	if (messageObj.type == "disableInpageAds")
	{
		inpageVideoAdsDisabled = true;
		// Next release, make it inpageAdsDisabled
		//inpageAdsDisabled = true;
		collapseAd();
	}

	if (messageObj.type == "closeVideo") {
		closeOver();
	}
}

function sendMessage(type,destinationModule,messageContentObj)
{
	var messageObj =
	{
		type: type,
		destination: destinationModule,
		content: messageContentObj,
		vendor: "WahWah",
		id: id
	};

	var message = JSON.stringify(messageObj);
	parent.postMessage(message, "*");
}

// Performance
function getTime() // It's fine if performance.now() isn't supported, as long as you call this routine for t1 and t2
{
	try
	{
		return window.performance.timing.navigationStart - 1403494338000 /* 6/23/2014 @ 3:32:18 GMT */ + window.performance.now();	// More accurate
	}
	catch(e)
	{
		return ( new Date().getTime);
	}
}

if (adConfig[adType].audioVolume != 0)
{
	audioVolume = adConfig[adType].audioVolume;
	hostaudio = true;
}

// CONTENT

var cb = (new Date().getTime());
var swfurl = adBase + "/wahwahadplayer.swf?cb=" + cb;
wwDebug.call(wwConsole, wwPrefix, "Ad Player URL: " + swfurl);

document.writeln("<div id=\"vidPlayback\" class=\"\">");
/*document.writeln("	<div id=\"close\"></div>");*/
document.writeln("	<div id=\"replay_video\"><img src=\"./images/unmute.png\" /><p>Audio On</p></div>");
document.writeln("</div>	");



// Important: For local testing, need to enable trusted location where you locate these files for EI to work and
// ad to contract on end of video ad
// http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager04.html

if (document.readyState === "complete")
{
	setTimeout(startLoad);
}
else
{
	addListener(document, "DOMContentLoaded", startLoad);
	addListener(window, "load", startLoad);
}

window.IN_FRIENDLY_FRAME = true;
// html5 player
document.writeln("<scr"+"ipt type=\"text/javascr"+"ipt\" src=\"./vast-vmap/vast-vmap.js\"></scr"+"ipt>");
//document.writeln("<scr"+"ipt type=\"text/javascr"+"ipt\" src=\"./videojs/video.js\"></scr"+"ipt>");
// Just always use video.dev.js since we do our own minification
document.writeln("<scr"+"ipt type=\"text/javascr"+"ipt\" src=\"./videojs/video.dev.js\"></scr"+"ipt>");
document.writeln("<scr"+"ipt type=\"text/javascr"+"ipt\" src=\"./videojs-ads/videojs.ads.js\"></scr"+"ipt>");
document.writeln("<scr"+"ipt type=\"text/javascr"+"ipt\" src=\"./ima-plugin/videojs.ima.js\"></scr"+"ipt>");
document.writeln("<scr"+"ipt type=\"text/javascr"+"ipt\" src=\"//imasdk.googleapis.com/js/sdkloader/ima3.js\"></scr"+"ipt>");
// lang for controls
// document.writeln("<scr"+"ipt type=\"text/javascr"+"ipt\" src=\"../../lang.js\" defer=\"defer\"></scr"+"ipt>");


var loadedXMLDoc = null;
function onQVSuccess(doc, identifier)
{
	wwLog.call(wwConsole, wwPrefix, "Loaded XML tag success. html5 request succeeded.");
	loadedXMLDoc = doc;
	setTimeout(function() { var sXML = wwSerialize(loadedXMLDoc); playerTechChoice(loadedXMLDoc, sXML); } );
}

function onQVFailure(type, obj, identifier, url)
{
	switch(type)
	{
		case "request":
			var request = obj;
			wwError.call(wwConsole, wwPrefix, "Failed requesting XML tag!");
			wwError.call(wwConsole, wwPrefix, "readyState=" + request.readyState + " status=" + request.status);
			wwError.call(wwConsole, wwPrefix, "url failure= " + url);
			if (request.status == 0)
			{
				wwError.call(wwConsole, wwPrefix, "Probably CORS header missing. Call Flash!");
				failToFlash();
				return;
			}
			else
				eiAdError();
			break;
		case "parse":
			wwError.call(wwConsole, wwPrefix, "Failed parsing!");
			eiAdError();
			break;
	}
}

function failToFlash()
{
	wwLog.call(wwConsole, wwPrefix, "Load XML in Flash here with URL: " + xmlTag);
	callFlashURL(xmlTag);
}


function fatalError()
{
		wwError.call(wwConsole, wwPrefix, "Call backup openx calls here through loader. this page unloads.")
		eiAdError();
}

function playerTechChoice(loadedXMLDoc, sXML)
{
	var vvLinear = loadedXMLDoc.ads[0].linear;
	if (typeof(vvLinear) == "undefined" || vvLinear == null)
	{
		wwError.call(wwConsole, wwPrefix, "VAST fatal error: No linear element")
		fatalError();
	}

	var vvmf = vvLinear.mediaFiles;
	var tagHTML5VPAID = false;
	var tagFlashVPAID = false;
	var tagFlashVideo = false;
	var tagHTML5Video = false;
	for (var i = 0; i < vvmf.length; i++)
	{
				var mediaf = vvmf[i];
				switch (mediaf["type"].toLowerCase())
				{
					case "video/mp4":
						tagFlashVideo = true;
						tagHTML5Video = true;
            break;
          case "video/x-flv":
						tagFlashVideo = true;
						break;
					case "application/x-shockwave-flash":
						if (mediaf["apiFramework"] && mediaf["apiFramework"].toLowerCase() == "vpaid")
							tagFlashVPAID = true;
						break;
					case "video/webm":
					case "video/ogg":
					case "video/3gp":
					// Todo: More specific browser checking. The files above don't work on every browser
						tagHTML5Video = true;
						break;
					case "application/javascript":

						if (mediaf["apiFramework"] && mediaf["apiFramework"].toLowerCase() == "vpaid")
						tagHTML5VPAID = true;
				}
	}

	wwLog.call(wwConsole, wwPrefix, ".........Decision logic time");
	wwLog.call(wwConsole, wwPrefix, "tagHTML5Video: " + tagHTML5Video);
	wwLog.call(wwConsole, wwPrefix, "tagFlashVideo: " + tagFlashVideo);
	wwLog.call(wwConsole, wwPrefix, "tagHTML5VPAID: " + tagHTML5VPAID);
	wwLog.call(wwConsole, wwPrefix, "tagFlashVPAID: " + tagFlashVPAID);

	var playerHeight = adConfig.inpage.vidHeight;

	// Make decision . Default to Flash for now on browsers that support and don't pause it and handle cases it wouldn't be paused in Chrome and Safari.
  if(tagHTML5Video){
    wwLog.call(wwConsole, wwPrefix, "Choosing html5 (uaBrowser=" + uaBrowser + ")");
    chosenAdTechnology = "html5";
    callHTML5(sXML);
  } else if ( (tagFlashVideo || tagFlashVPAID) && ( (uaBrowser != "Safari" && uaBrowser != "Chrome" ) || /* is safari or chrome and */ playerHeight >= 300) )
	{
		wwLog.call(wwConsole, wwPrefix, "Choosing Flash (uaBrowser=" + uaBrowser + " and height="+playerHeight+")");
		chosenAdTechnology = "flash";
		callFlashXML(sXML);
	}
	else if (tagHTML5VPAID)
	{
		wwLog.call(wwConsole, wwPrefix, "Choosing html5 (uaBrowser=" + uaBrowser + ")");
		chosenAdTechnology = "html5";
		callHTML5(sXML);
	}
	else
	{
		wwLog.call(wwConsole, wwPrefix, "Tag does not contain a valid MediaFile option! (uaBrowser=" + uaBrowser + ")");
		eiAdError();
	}

}

var chosenAdTechnology = ""; // "flash" | "html5";


var cacheBusterReplaceArray = ["\\[timestamp\\]", "\\[cachebuster\\]", "\\[random\\]", "\\[randnum\\]"];
var cacheBuster = Math.round(100000000000 * Math.random());
function replaceWildcardWithCacheBuster( urlToTag)
{

	for(var i = 0; i < cacheBusterReplaceArray.length; i++)
	{
		urlToTag = urlToTag.replace(new RegExp(cacheBusterReplaceArray[i],"gi"), cacheBuster);
	}

	return urlToTag;
}

function callFlashURL(url)
{
	wwLog.call(wwConsole, wwPrefix, "Calling flash url: " + xmlTag);
	writeFlash(url, null);
}

var callTimer;
var counter = 1;

function callFlashXML(xml)
{
	wwLog.call(wwConsole, wwPrefix, "Calling XML into Flash");
	wwDebug.call(wwConsole, wwPrefix, "XML: " + xml);

	writeFlash(null, xml);

	wwDebug.call(wwConsole, wwPrefix, "Starting timer... ");
	callTimer = window.setTimeout(timedOut, 8000);
}


function timedOut() {
	wwDebug.call(wwConsole, wwPrefix, "Timed Out...");
	window.clearTimeout(callTimer);
	eiAdError();
}

function writeFlash(url, xml)
{
	var swfurl = "./wahwahadplayer.swf";
	var attributes = 'data="' + swfurl + '" type="application/x-shockwave-flash"';
	if (typeof(window.ActiveXObject) != "undefined")
			attributes = 'codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,2,0" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"'; // IE9
	var vidWidth = adConfig.inpage.vidWidth;
	var vidHeight = adConfig.inpage.vidHeight;
	var flashvars;
	if (xml != null)
		flashvars = 'AD_XML='+escape(xml)+'&SCALE=true&COUNTDOWN=false&HOSTAUDIO='+hostaudio+'&HOSTVOLUME='+audioVolume;
	else
		flashvars = 'AD_URL='+escape(url)+'&SCALE=true&COUNTDOWN=false&HOSTAUDIO='+hostaudio+'&HOSTVOLUME='+audioVolume;
	var objTag = '<object id="wahwahadplayer" name="wahwahadplayer" width="'+vidWidth+'" height="'+vidHeight+'" id="wahwahadplayer" '+attributes+'><param name="movie" value="' + swfurl + '" /><param name="FlashVars" value="'+flashvars+'" /><param name="allowfullscreen" value="true"/><param name="allowscr'+'iptaccess" value="always" /><param name="scale" value="noScale" /><param name="quality" value="best" /><param name="bgcolor" value="#ffffff" /><param name="wmode" value="transparent"/></object>';
	var div = document.createElement('div');
	document.getElementById("vidPlayback").appendChild(div);
	div.innerHTML += objTag;
}


  var adEvents;


function _onAdEvent(event) {
  wwLog.call(wwConsole, wwPrefix, '*****Ad event: ' + event.type);
  switch (event.type)
  {
  		case google.ima.AdEvent.Type.ALL_ADS_COMPLETED:
			// eiAdCompleted();
		break;
		case google.ima.AdEvent.Type.CLICK:

		break;
		case google.ima.AdEvent.Type.COMPLETE:
			// Only support one ad at a time for now (may change later?)
			eiAdCompleted();
		break;
		case google.ima.AdEvent.Type.FIRST_QUARTILE:

		break;
		case google.ima.AdEvent.Type.LOADED:

		break;
		case google.ima.AdEvent.Type.MIDPOINT:

		break;
		case google.ima.AdEvent.Type.PAUSED:

		break;
		case google.ima.AdEvent.Type.STARTED:

		break;
		case google.ima.AdEvent.Type.THIRD_QUARTILE:

		break;
	}
}

function imaLoaded(event)
{

	// Doesn't seem to do anything with IMA (it either treats it as on or off)
	html5Player.ima.getAdsManager().setVolume(audioVolume / 100);

	 adEvents = [
		google.ima.AdEvent.Type.ALL_ADS_COMPLETED,
		google.ima.AdEvent.Type.CLICK,
		google.ima.AdEvent.Type.COMPLETE,
		google.ima.AdEvent.Type.FIRST_QUARTILE,
		google.ima.AdEvent.Type.LOADED,
		google.ima.AdEvent.Type.MIDPOINT,
		google.ima.AdEvent.Type.PAUSED,
		google.ima.AdEvent.Type.STARTED,
		google.ima.AdEvent.Type.THIRD_QUARTILE
	  ];

		// Adsmanager loaded
		  wwLog.call(wwConsole, wwPrefix,'*****imaLoaded event: ' + event.type);

		  for (var index = 0; index < adEvents.length; index++) {
			html5Player.ima.addEventListener(
				adEvents[index],
				_onAdEvent);
		  }
			html5Player.ima.start();

}

function callHTML5(xml)
{
	wwLog.call(wwConsole, wwPrefix, "Calling HTML5 with XML");
	wwDebug.call(wwConsole, wwPrefix, "XML: " + xml);
	//Wait until google object is ready
	if (typeof(google) == "undefined")
	{
		// Google not ready
		setTimeout(function() {
			callHTML5(xml)
		},200);
		return;
	}

  var div = document.createElement('div');
  document.getElementById("vidPlayback").appendChild(div);
  div.innerHTML += ''
  + ' <video id="content_video" class="video-js vjs-default-skin" preload="auto" width="'+adConfig.inpage.vidWidth+'" height="'+adConfig.inpage.vidHeight+'" >'
// uppress error on initial load    + '  <source src="about:blank" type="video/mp4" ></source>'
  + ' </video>';
  html5Player = videojs('content_video');
  var player = html5Player;

  var options = {
      id: 'content_video',
      adsResponse: xml,
      //adRenderingSettings: ,
      //contribAdsSettings: ,
      debug: false,
      locale: 'en',
      nonLinearWidth: adConfig.inpage.vidWidth,
      nonLinearHeight: adConfig.inpage.vidHeight,
      showCountdown: false,
      vpaidMode: google.ima.ImaSdkSettings.VpaidMode.ENABLED // ENABLED, INSECURE, DISABLED

  };

	if (wahwah.logLevel == "debug" || wahwah.debugMode == true)
	{
		options.debug = true;
	}


//adsLoader.getSettings().setVpaidMode(google.ima.ImaSdkSettings.VpaidMode.INSECURE);


	player.ima(options, imaLoaded);

	// Remove controls from the player on iPad to stop native controls from stealing
	// our click
	var contentPlayer =  document.getElementById('content_video_html5_api');
	if ((navigator.userAgent.match(/iPad/i) ||
		  navigator.userAgent.match(/Android/i)) &&
		contentPlayer.hasAttribute('controls')) {
	  contentPlayer.removeAttribute('controls');
	}

	// Initialize the ad container when the video player is clicked, but only the
	// first time it's clicked.
	var startEvent = 'click';
	if (navigator.userAgent.match(/iPhone/i) ||
		navigator.userAgent.match(/iPad/i) ||
		navigator.userAgent.match(/Android/i)) {
	  startEvent = 'tap';
	}


//player.one(startEvent, function() {
    player.ima.initializeAdDisplayContainer();
    player.ima.requestAds();
    player.play();
	player.muted(!hostaudio);
	// throws an error here line 224 of videojs.ima.js player.volume = audioVolume/100;	// percent as fraction
	// Is there a better way to do the following?
	var el = document.getElementById("content_video_html5_api");
	el.style.position="absolute";
	el.style.zIndex="1";
	el.style.top="0px";
	el.style.left="0px";
	el = document.getElementById("ima-ad-container");
	el.style.position="absolute";
	el.style.zIndex="2";
	el.style.top="0px";
	el.style.left="0px";
//});


	html5StartMessages();

}

var html5Player;





function html5StartMessages()
{

	eiShowPlaying (true);
}

// ========================================================================
// START SERIALIZATION CODE

function CreateMSXMLDocumentObject () {
    if (typeof (ActiveXObject) != "undefined") {
        var progIDs = [
                        "Msxml2.DOMDocument.6.0",
                        "Msxml2.DOMDocument.5.0",
                        "Msxml2.DOMDocument.4.0",
                        "Msxml2.DOMDocument.3.0",
                        "MSXML2.DOMDocument",
                        "MSXML.DOMDocument"
                      ];
        for (var i = 0; i < progIDs.length; i++) {
            try {
                return new ActiveXObject(progIDs[i]);
            } catch(e) {};
        }
    }
    return null;
}

function CreateXMLDocumentObject (rootName) {
    if (!rootName) {
        rootName = "";
    }
    var xmlDoc = CreateMSXMLDocumentObject();
    if (xmlDoc) {
        if (rootName) {
            var rootNode = xmlDoc.createElement (rootName);
            xmlDoc.appendChild (rootNode);
        }
    }
    else {
        if (document.implementation.createDocument) {
            xmlDoc = document.implementation.createDocument ("", rootName, null);
        }
    }

    return xmlDoc;
}

function addAttribute(doc, element, name, value)
{
	var attr = doc.createAttribute(name);
	attr.value = value;
	element.setAttributeNode(attr);
	return element;	// Makes one-liners easier
}

function conditionalCreateCDATAInfoElement(doc, parentElement, name, innerText)
{
		if (typeof(innerText) != "undefined" && innerText != null)
		{

			var element = doc.createElement(name);
			parentElement.appendChild(element);
			element.appendChild(doc.createCDATASection( innerText ));
			return element;
		}
		return null;
}

function conditionalCreateAttribute(doc, element, name, value)
{
	if (typeof(value) != "undefined" && value != null)
	{
		addAttribute(doc, element, name, value)
	}
}

function createTrackingElementsFromCollection(doc, parentElement, name, collection)
{
	if (typeof(collection.length) != "undefined") // Impresions, Errors
	{
		for (var i = 0; i < collection.length; i++)
		{
			var value;
			var isImpr = false;
			if (typeof(collection[i].id) != "undefined") // Impressions
			{
				value = collection[i].url;
				isImpr = true;
			}
			else // Misc
			{
				value = collection[i];
			}
			var element = conditionalCreateCDATAInfoElement(doc, parentElement, name, value);
			if (isImpr)
			{
				conditionalCreateAttribute(doc, element, "id", collection[i].id);
			}
		}
	}
	else // TrackingEvents
	{
		for (var n in collection)
		{
			var trackArray = collection[n];
			for (var i = trackArray.length - 1; i >= 0; i--)	// Go backwards to put non-wrappers first (for players that support only 1 of each)
			{
				var track = trackArray[i];
				if (track.event != "click")
				{
					var element = conditionalCreateCDATAInfoElement(doc, parentElement, name, track.url);
					conditionalCreateAttribute(doc, element, "event", track.event);
				}
			}
		}
	}
}


function appendNewline(doc, siblingNode)
{
	siblingNode.parentNode.insertBefore(doc.createTextNode("\n"), siblingNode.nextSibling);
}

function processAttributeList(doc, element, attributesArray /* named array */)
{
	for (var attr in attributesArray)
	{
		var val = attributesArray[attr];
		switch (attr) {
			case 'skipoffset':
			case 'duration':
			case 'offset':
			case 'minSuggestedDuration':
			  val = makeVASTTime(val);
		  }
		conditionalCreateAttribute(doc, element, attr, val);
	}
}

function makeVASTTime(sec)
{
	function zeroFill( number, width )
	{
		width -= number.toString().length;
		if ( width > 0 )
		{
			return new Array( width + (/\./.test( number ) ? 2 : 1) ).join( '0' ) + number;
		}
		return number + ""; // always return a string
	}
	var hours = Math.floor(sec / 3600);
	sec -= hours*3600;
	var min = Math.floor(sec / 60);
	sec -= min*60;
	return zeroFill(hours,2) + ":" + zeroFill(min,2) + ":" + zeroFill(sec,2);

}

// http://help.dottoro.com/ljbcjfot.php
function wwSerialize(vvDoc)
{
	wwLog.call(wwConsole, wwPrefix, "Serializing doc");

	var vastXML = CreateXMLDocumentObject("VAST");
	var rootNode = vastXML.firstChild;
	// TODO: Make 3.0 someday
	addAttribute(vastXML, rootNode, "xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
	addAttribute(vastXML, rootNode, "xsi:noNamespaceSchemaLocation", "vast.xsd");
	addAttribute(vastXML, rootNode, "version", "2.0");

	for (var adNum = 0; adNum < vvDoc.ads.length; adNum++)
	{
		var adNode = vastXML.createElement("Ad");
		conditionalCreateAttribute(vastXML, adNode, "id", vvDoc.ads[adNum].properties.id); // Ad.id
		rootNode.appendChild(adNode);
		// All wrappers' tracking is combined w/ final tag by now, so should always be InLine
		var inLine = adNode.appendChild(vastXML.createElement("InLine"));
		var adSystem = conditionalCreateCDATAInfoElement(vastXML, inLine, "AdSystem", vvDoc.ads[adNum].properties.AdSystem);
		// TODO: I don't think we're collecting AdSystem.version yet
		if (adSystem != null)
		{
			conditionalCreateAttribute(vastXML, adSystem, "version", vvDoc.ads[adNum].properties.AdSystemVersion);
		}
		conditionalCreateCDATAInfoElement(vastXML, inLine, "AdTitle", vvDoc.ads[adNum].properties.AdTitle);
		conditionalCreateCDATAInfoElement(vastXML, inLine, "Description", vvDoc.ads[adNum].properties.Description);
		conditionalCreateCDATAInfoElement(vastXML, inLine, "Survey", vvDoc.ads[adNum].properties.Survey);
		createTrackingElementsFromCollection(vastXML, inLine, "Impression", vvDoc.ads[adNum].impressions); // Impressions are unique in that they have an id that we have to take into consideration
		// TODO: We are breaking vast 2.0.1 and VAST 3 spec by allowing multiple errors (wrapper, children) and will need to extract them later, handle them out-of-bound or something
		createTrackingElementsFromCollection(vastXML, inLine, "Error", vvDoc.ads[adNum].errors);


		var creatives = inLine.appendChild(vastXML.createElement("Creatives"));
		// Add Linear
		if (vvDoc.ads[adNum].linear)
		{
			var creative = creatives.appendChild(vastXML.createElement("Creative"));
			var linear = creative.appendChild(vastXML.createElement("Linear"));
			var vvLinear = vvDoc.ads[adNum].linear;
			processAttributeList(vastXML, creative, vvLinear.creativeAttributes);
			conditionalCreateCDATAInfoElement(vastXML, linear, "Duration", makeVASTTime(vvDoc.ads[adNum].linear.duration));
			var trackingEvents = linear.appendChild(vastXML.createElement("TrackingEvents"));
			var events = vvLinear.tracking.events;
			createTrackingElementsFromCollection(vastXML, trackingEvents, "Tracking", events);
			var mediaFiles = linear.appendChild(vastXML.createElement("MediaFiles"));
			var vvmf = vvLinear.mediaFiles;
			for (var i = 0; i < vvmf.length; i++)
			{
				var mediaf = vvmf[i];
				var mediaFile = conditionalCreateCDATAInfoElement(vastXML, mediaFiles, "MediaFile", mediaf["src"]);
				conditionalCreateAttribute(vastXML, mediaFile, "id", mediaf["id"]);
				conditionalCreateAttribute(vastXML, mediaFile, "delivery", mediaf["delivery"]);
				conditionalCreateAttribute(vastXML, mediaFile, "type", mediaf["type"]);
				conditionalCreateAttribute(vastXML, mediaFile, "bitrate", mediaf["bitrate"]);
				conditionalCreateAttribute(vastXML, mediaFile, "width", mediaf["width"]);
				conditionalCreateAttribute(vastXML, mediaFile, "height", mediaf["height"]);
				conditionalCreateAttribute(vastXML, mediaFile, "scalable", mediaf["scalable"]);
				conditionalCreateAttribute(vastXML, mediaFile, "maintainAspectRatio", mediaf["maintainAspectRatio"]);
				conditionalCreateAttribute(vastXML, mediaFile, "apiFramework", mediaf["apiFramework"]);
			}
			var videoClicks = linear.appendChild(vastXML.createElement("VideoClicks"));
			if (typeof(events["click"]) != "undefined")
			{
				for (var i = 0; i < events["click"].length; i++)
				{
					conditionalCreateCDATAInfoElement(vastXML, videoClicks, "ClickTracking", events["click"][i].url);
				}
			}
			conditionalCreateCDATAInfoElement(vastXML, videoClicks, "ClickThrough", vvLinear.clickThrough);
			conditionalCreateCDATAInfoElement(vastXML, linear, "AdParameters", vvLinear.adParameters);

		}

		// Add NonLinear
		if (vvDoc.ads[adNum].nonlinears.length > 0)
		{
			var creative = creatives.appendChild(vastXML.createElement("Creative"))
			var nonLinearAds = creative.appendChild(vastXML.createElement("NonLinearAds"));

			var trackingEvents = nonLinearAds.appendChild(vastXML.createElement("TrackingEvents"));
			var events = vvDoc.ads[adNum].nonlinearsTracking.events;
			createTrackingElementsFromCollection(vastXML, trackingEvents, "Tracking", events);

			var vvDocNonLinears = vvDoc.ads[adNum].nonlinears;
			for (var j = 0; j < vvDocNonLinears.length; j++)
			{
				var vvNonLinear = vvDocNonLinears[j];
				var nonLinear = nonLinearAds.appendChild(vastXML.createElement("NonLinear"));
				processAttributeList(vastXML, creative, vvNonLinear.creativeAttributes);
				processAttributeList(vastXML, nonLinear, vvNonLinear.attributes);
				conditionalCreateCDATAInfoElement(vastXML, nonLinear, "NonLinearClickThrough", vvNonLinear.clickThrough);
				conditionalCreateCDATAInfoElement(vastXML, nonLinear, "AdParameters", vvNonLinear.adParameters);
				var vvResources = vvNonLinear.resources;
				conditionalCreateCDATAInfoElement(vastXML, nonLinear, "IFrameResource", vvResources.iframe);
				conditionalCreateCDATAInfoElement(vastXML, nonLinear, "HTMLResource", vvResources.html);
				for (var imgType in vvResources.images)
				{
					var staticResource = conditionalCreateCDATAInfoElement(vastXML, nonLinear, "StaticResource", vvResources.images[imgType]);
					conditionalCreateAttribute(vastXML, staticResource, "creativeType", imgType)
				}
			}
		}

		// Add Companions
		if (vvDoc.ads[adNum].companions.length > 0)
		{
			var creative = creatives.appendChild(vastXML.createElement("Creative"))
			var companionAds = creative.appendChild(vastXML.createElement("CompanionAds"));
			var vvDocCompanions = vvDoc.ads[adNum].companions;
			for (var j = 0; j < vvDocCompanions.length; j++)
			{
				var companion = companionAds.appendChild(vastXML.createElement("Companion"));
				var vvCompanion = vvDocCompanions[j];
				processAttributeList(vastXML, creative, vvCompanion.creativeAttributes);
				processAttributeList(vastXML, companion, vvCompanion.attributes);
				var trackingEvents = companion.appendChild(vastXML.createElement("TrackingEvents"));
				var events = vvCompanion.tracking.events;
				createTrackingElementsFromCollection(vastXML, trackingEvents, "Tracking", events);
				conditionalCreateCDATAInfoElement(vastXML, companion, "CompanionClickThrough", vvCompanion.clickThrough);
				conditionalCreateCDATAInfoElement(vastXML, companion, "AltText", vvCompanion.altText);
				conditionalCreateCDATAInfoElement(vastXML, companion, "AdParameters", vvCompanion.adParameters);
				var vvResources = vvCompanion.resources;
				conditionalCreateCDATAInfoElement(vastXML, companion, "IFrameResource", vvResources.iframe);
				conditionalCreateCDATAInfoElement(vastXML, companion, "HTMLResource", vvResources.html);
				for (var imgType in vvResources.images)
				{
					var staticResource = conditionalCreateCDATAInfoElement(vastXML, companion, "StaticResource", vvResources.images[imgType]);
					conditionalCreateAttribute(vastXML, staticResource, "creativeType", imgType)
				}
			}
		}

		var vvExtensions = vvDoc.ads[adNum].extensions;
		if (vvExtensions.length > 0)
		{

			var extensions = inLine.appendChild(vastXML.createElement("Extensions"));
			for (var i = 0; i < vvExtensions.length; i++)
			{
				// No CDATA here. Just trust what tag sent (otherwise we could end up with invalid XML from CDATA inside CDATA)
				var extension = extensions.appendChild(vastXML.createElement("Extension"));
				extension.appendChild(vastXML.createTextNode(vvExtensions[i].value));
				conditionalCreateAttribute(vastXML, extension, "type", vvExtensions[i].type)
			}

		}
	}

	var xmlSerializer = new XMLSerializer();
	var s = xmlSerializer.serializeToString(vastXML);
	if (s.indexOf("<?xml") == -1)
		s = '<?xml version="1.0" encoding="'+vastXML.characterSet+'"?>' + s;
	return s;
}
