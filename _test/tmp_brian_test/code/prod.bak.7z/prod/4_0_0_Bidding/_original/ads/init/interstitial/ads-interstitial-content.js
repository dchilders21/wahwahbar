
document.writeln('<div id="adControlsOverlay"><div id="ad_text" data-lang="AD_TEXT"></div><div id="until_close_text" data-lang="UNTIL_CLOSE_TEXT"></div><img id="close" src="./images/clear.gif">&nbsp;</div><div id="adContainer"></div>');
document.writeln('<div id="adCountdownHolder"><img src="./images/pause.png" id="playpause" style="display: none"><div id="countdown"><span id="countdown_text" data-lang="COUNTDOWN_TEXT"><span id="countdown_counter"></span></span></div></div>');
	/*
<!-- Quantcast Tag -->
<!-- info: www.quantcast.com/help/webmeasurement/ -->
<scr ipt type="text/javascr ipt">*/
var _qevents = _qevents || [];

(function() {
var elem = document.createElement('script');
elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://edge") + ".quantserve.com/quant.js";
elem.async = true;
elem.type = "text/javascript";
var scpt = document.getElementsByTagName('script')[0];
scpt.parentNode.insertBefore(elem, scpt);
})();

_qevents.push({
qacct:"p-G6YV9Jxa98hZW"
});
/*
</scr ipt>*/

/*
// No way to load ad without script enabled
<noscript>
<div style="display:none;">
<img src="//pixel.quantserve.com/pixel/p-G6YV9Jxa98hZW.gif" border="0" height="1" width="1" alt="Quantcast"/>
</div>
</noscript>
*/

/*
<!-- End Quantcast tag -->
*/
