/* Avoid `console` errors in browsers that lack a console. Modified based on: http://html5boilerplate.com/ */ (function() { var method; var noop = function () {}; var methods = ['debug','error','info', 'log','warn']; var length = methods.length; var console = (window.console = window.console || {}); while (length--) { method = methods[length]; /* Only stub undefined methods. */ if (!console[method]) { console[method] = noop; } } }()); /* First, check if IE running in Quirks mode, which treats window.console.log as an object, not ECMAScript function, and doesn't support .call on that object */ if (typeof(window.console.log.call) != "function") { console.warn("[Wahwah] This debugger doesn't support console.* as a function / console.log.call, etc. Possibly IE in Quirks/Compatibility mode or Firebug. View on web or localhost (not local or intranet) and in HTML5 or use a debug toolbar that supports console.* as a true ECMAScript function.");  /* Next, create console.log placeholder if it doesn't exist */	window.console = { 	debug : function() {}, 	error: function() {}, info: function() {}, 	log: function() {}, warn: function() {} }; }; /* Create addListener placeholder, when it doesn't exist */ var addListener = function (e, t, n) { if ("addEventListener" in e) { e.addEventListener(t, n, true) } else if ("attachEvent" in e) { var r = function () { n(window.event) }; e.attachEvent("on" + t, r) } }; var removeListener = function (e, t, n) { if ("removeEventListener" in e) { e.removeEventListener(t, n, true) } else if ("detachEvent" in e) { var r = function () { n(window.event) }; e.detachEvent("on" + t, r) } }


function getParameterByName(name)
{
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var results = regex.exec( window.location.href );
  if( results == null )
    return "";
  else
    return decodeURIComponent(results[1].replace(/\+/g, " "));
}


var wahwah = {logLevel: getParameterByName("logLevel")};


var hash = window.location.hash.split('/');

wahwah.id = hash[1];
wahwah.app = hash[2];
wahwah.skin = hash[3];
wahwah.lan = hash[4].substring(0,2);

// Todo: Pass up the parent window chain when possible
// Later, replace with htm5 BroadcastChannel message when all browsers support to decrease size
if (typeof(window.wwMsg) == "undefined")
{
	window.wwMsg = new function() {
		this._module = "Ads Init";
		this._prefix = function(module)
		{
			if (module == null)
			{
				module = this._module;
			}
			return "[Wahwah " + module + "] ";
		}
		this._debugLevelInt = function()
		{
			switch(wahwah.logLevel)
			{
				case "debug":
					return 3;
					break;
				case "info":
					return 2;
					break;
				case "warn":
					return 1;
					break;
				case "error":
					return 0;
					break;
				default:
					return 0;
			}
		}
		this.forceLogProto = function()
		{
			return console.log;
		}
		this.errorProto = function() 
		{
			if (this._debugLevelInt() >= 0)
				return console.error;
			else
				return (function () {})
		}
		this.warnProto = function() 
		{
			if (this._debugLevelInt() >= 1)
				return console.warn;
			else
				return (function () {})
		}
		this.logProto = function() 
		{
			if (this._debugLevelInt() >= 2)
				return console.log;
			else
				return (function () {})
		}
		this.debugProto = function() 
		{
			if (this._debugLevelInt() >= 3)
				return console.debug;
			else
				return (function () {})
		}
		this.infoProto = function() {return this.logProto()}	


	}
	
		// easier minification
		var wwConsole = window.console;
		var wwPrefix = window.wwMsg._prefix(null);
		var wwLog = window.wwMsg.logProto();
		var wwWarn = window.wwMsg.warnProto();
		var wwDebug = window.wwMsg.debugProto();
		var wwError = window.wwMsg.errorProto();
		var wwInfo = window.wwMsg.infoProto();
		var wwForceLog = window.wwMsg.forceLogProto(); // Use sparingly
}
	
var adConfig = null;
var adOnly = false;
var placementType = null;

if (wahwah.app == "adOnly") {
	adOnly = true;
}

trackAdImpression();

var ModuleEnums = {
    MODULE_LOADER: "Loader",
    MODULE_TOOLBAR: "Toolbar",
    MODULE_RADIO: "Radio",
    MODULE_ADS: "Ads"
};

var PlacementTypes = {
        AD_728_FLASH: "728F",
        AD_300_FLASH: "300F",
        BACKUP_AD_300_FLASH: "300B",
        AD_300_MOBILE: "300M",
        AD_728_MOBILE: "728M",
        AD_320_MOBILE: "320M"
};

if (typeof console == "undefined")
{
    var console = {};
    wwLog = function () { };
}


wwDebug.call(wwConsole, wwPrefix, "ads-common ts=" + getTime());

var addListener = function (obj, event, handler)
{
    if (typeof addEventListener != "undefined")
    {
        obj.addEventListener(event, handler, true);
    } else if (typeof attachEvent != "undefined")
    {
        var newHandler = function ()
        {
            handler(window.event);
        };

        obj.attachEvent("on" + event, newHandler);
    }
};

var removeListener = function (obj, event, handler)
{
    if (typeof removeEventListener != "undefined")
    {
        obj.removeEventListener(event, handler, true);
    } else if (typeof detachEvent != "undefined")
    {
        var newHandler = function ()
        {
            handler(window.event);
        };

        obj.detachEvent("on" + event, newHandler);
    }
};

function readyToLoad() 
{
	wwLog.call(wwConsole, wwPrefix, "Ad module ready to load.");

	removeListener(document, "DOMContentLoaded", readyToLoad);
	removeListener(window, "load", readyToLoad);
	addListener(window, "message", handleMessage);
	
	// Only load after we receive custom features
	sendMessage("getClientFeatures", ModuleEnums.MODULE_LOADER, {});
}

wahwah.clientFeatures = {};
var referrer;
var domain;

function startLoad()
{
	wwLog.call(wwConsole, wwPrefix, "Ad module loaded.");
	trackAdLoad();
	
	loadPreference = getParameterByName("loadPreference");

	placementType = getParameterByName("placementType");

	
	var adconfigParamStr = getParameterByName("adconfig");
	if (adconfigParamStr == null || adconfigParamStr == "")
	{
		// Not found. Load defaults
		adConfig = JSON.parse('adconfig: {"display": { "enabled": false, "width": 300, "vidFreq": 0.75  },"interstitial": {"enabled": false} , "linear": {"enabled": false }	}');
	}
	else
	{

		//var referrer = document.referrer;
		var referrer = getParameterByName("referrer");
		//referrer = "http://localhost:8888/LOCAL_TEST.html";
		adconfigParamStr = adconfigParamStr.replace(/\$\{REFERRER\}/gi, encodeURIComponent(referrer));
		// Stop-gap. Force pass referrer along with Openx video URIs. Better to add ${REFERRER} this on platform side
		// BAR-182 : stop-gap for PLATFORM-160 . See also http://docs.openx.com/ad_server/adtagguide_parameters.html
		var isVideo = (adconfigParamStr.indexOf("ref=") == -1 && adconfigParamStr.indexOf("wahwahnetworks.com/v/1.0/av?auid=") != -1)
		if (isVideo)
		{
			domain = (referrer.split("//")[1]).split('/')[0];
			var openxDomainInfo = "c.domain="+encodeURIComponent(domain)+"&c.widget_id="+encodeURIComponent(wahwah.id);
			// clientFeatures pub_custom
			var openxPubCustom = "";
			// Duplicated in displayadframe.js and vidplayerframe.js
			if (wahwah.clientFeatures.hasOwnProperty("customPublisherReportKeyValues"))
			{ 
				var customPubReportVals = JSON.stringify(wahwah.clientFeatures["customPublisherReportKeyValues"]);
				// Macros
				customPubReportVals = customPubReportVals.replace(/\$\$/g,"${$}");
				customPubReportVals = customPubReportVals.replace(/\$\{REFERRER\}/gi,encodeURIComponent(referrer));
				customPubReportVals = customPubReportVals.replace(/\$\{DOMAIN\}/gi,encodeURIComponent(domain));
				customPubReportVals = customPubReportVals.replace(/\$\{\$\}/g,"$");
				openxPubCustom="&c.pub_custom="+encodeURIComponent(customPubReportVals);
			}
			adconfigParamStr = adconfigParamStr.replace(/av\?auid/gi, "av?"+openxDomainInfo + openxPubCustom + "&ref=" + encodeURIComponent(referrer) + "&auid");
		}
		adConfig = JSON.parse(adconfigParamStr);

	}
		
	window["startLoad_"+adType]();
	
}
	

	
function handleMessage(evt)
{
    if (!evt) evt = window.event;

		try {
			var messageObj = JSON.parse(evt.data);
		}
		catch(e) {
			return;
		}
		if (messageObj.id == placementId) {
			if ( messageObj.type == "clientFeatures")
			{
				wahwah.clientFeatures = messageObj.content;
				startLoad();
			}
			if ( messageObj.type == "onAdVideoPlayerComplete") // From video ad player 
			{
				onVideoCompleted();
			}
			if ( messageObj.type == "clearCollapse") // From Loader when determined as a custom campaign 
			{
				clearCollapse();
			}
			else if (messageObj.type == "onAdVideoPlayerError") // From video ad player
			{
				onVideoError();
			}
			else if (messageObj.type == "onAdDisplayError") // From display ad
			{	
				onDisplayError();
			}
			else if (messageObj.type == "onAdSuccessfulLoad") // From video ad player or display ad
			{	
				onSuccessfulLoad(messageObj.content["customCampaign"], messageObj.content["customCampaignName"], messageObj.content["isVideo"]);
			} 
			else if ( messageObj.type == "updateCookie") {
				sendMessage("updateCookie", ModuleEnums.MODULE_LOADER, {});
			} 
			else if ( messageObj.type == "showDefyAudio") {
				sendMessage("showDefyAudio", ModuleEnums.MODULE_LOADER, {}); 
			}
			else if ( messageObj.type == "closeVideo")
			{
				endCollapse();
			}
			else if ( messageObj.type == "onUpdateCountdown")
			{
				onUpdateCountdown(messageObj.content["remaining"], messageObj.content["duration"]);
			}
			else // specific to adType
				window["handleMessage_"+adType](evt);
		} else {
			//wwDebug.call(wwConsole, wwPrefix, "Ads-Common :: Improper UUID"); 
		}
}

function sendMessage(type,destinationModule,messageContentObj)
{
    var messageObj =
    {
        type: type,
        destination: destinationModule,
        content: messageContentObj,
        id: placementId
    };
    var message = JSON.stringify(messageObj);
    parent.postMessage(message, "*");
}





function trackAdLoad()
{
	wwDebug.call(wwConsole, wwPrefix, "trackAdLoad");
}
function trackAdImpression()	// As close to when ad server is called as possible, via msg from ad module
{
	wwDebug.call(wwConsole, wwPrefix, "trackImpression");
}




if (document.readyState === "complete") {
    setTimeout(readyToLoad);
} else {
    addListener(document, "DOMContentLoaded", readyToLoad);
    addListener(window, "load", readyToLoad);
}

// Performance
function getTime() // It's fine if performance.now() isn't supported, as long as you call this routine for t1 and t2
{
	try
	{
		return window.performance.timing.navigationStart - 1403494338000 /* 6/23/2014 @ 3:32:18 GMT */ + window.performance.now();	// More accurate
	}
	catch(e)
	{
		return ( new Date().getTime);
	}
}




/******************************************************* 
				LOAD AD
*******************************************************/

var adType = getParameterByName("adType");
var uaBrowser = getParameterByName("uaBrowser");
var placementType = getParameterByName("placementType");
var displayType = getParameterByName("displayType");
var adReloaded = getParameterByName("adReloaded");
var placementId = getParameterByName("placementId");
var loadPreference;


function loadjscssfile(filename, filetype)
{
	if (filetype=="js")
	{ 
		var fileref=document.createElement('script');
		fileref.setAttribute("type","text/javascript");
		fileref.setAttribute("src", filename);
	}
	else if (filetype=="css")
	{ 
		var fileref=document.createElement("link");
		fileref.setAttribute("rel", "stylesheet");
		fileref.setAttribute("type", "text/css");
		fileref.setAttribute("href", filename);
	}
	if (typeof fileref!="undefined")
		document.getElementsByTagName("head")[0].appendChild(fileref);
}
// Don't use loadjscssfile for any critical js, since it may not load in time
loadjscssfile("init/"+adType+"/ads-"+adType +".css", "css");


// For the html specific to a particular ad type
document.writeln('<scr'+'ipt src="init/'+adType+'/ads-'+adType +'.js" type="text/javascr'+'ipt" ></scr'+'ipt>');	
document.writeln('<scr'+'ipt src="init/'+adType+'/ads-'+adType +'-content.js" type="text/javascr'+'ipt" ></scr'+'ipt>');

