var AdPlacement = {
    DISPLAY_AD: "Display",
    VIDEO_AD: "Video"
};


var currentAdType = null;
var countdownInterval = -1;
var allowCloseButtonCountdownInterval = -1;
var allowCloseButtonCountdown = 0;

var displayCount = 0;


function adControlsOverlayPressed()
{
    // Close button was pressed
	if (allowCloseButtonCountdown == 0)
		closeAd();
}

var interstitial;

function startLoad_interstitial() 
{
	wwLog.call(wwConsole, wwPrefix, "Ad module - Intertistial loaded.");
	
	addListener(document.getElementById("close"), "mouseup", adControlsOverlayPressed);
	
	if (typeof(adConfig.interstitial.displayURL) == "undefined")
		adConfig.interstitial.displayURL = "";
	if (typeof(adConfig.interstitial.vidURL) == "undefined")
		adConfig.interstitial.vidURL = "";
	
	interstitial = adConfig.interstitial;
	
	// Shouldn't get here. Catch in loader instead. Just in case
	if (interstitial.enabled == false)
	{
		wwForceLog.call(wwConsole, wwPrefix, "Interstitial disabled");
		closeAd();
	}
	
	var width = interstitial.width;
	var height = interstitial.height+15;
	var adContainer = document.getElementById("adContainer");
	var adCountdownHolder = document.getElementById("adCountdownHolder");
	var adControlsOverlay = document.getElementById("adControlsOverlay");
	adContainer.style.visibility = "visible"; // Can't hide or IE won't load
	adControlsOverlay.style.visibility = "hidden";
	adCountdownHolder.style.visibility = "hidden";
	adContainer.style.width = width + "px";
	adContainer.style.height = height + "px";
	adContainer.style.margin = "0 auto";
	adContainer.style.marginLeft = -Math.floor(width/2) + "px";
	adContainer.style.marginTop = -Math.floor(height/2) + "px";
	adControlsOverlay.style.marginLeft = -Math.floor(width/2) + "px";
	adControlsOverlay.style.marginTop = -Math.floor(height/2) + "px";
	adControlsOverlay.style.width = width + "px";
	
	adCountdownHolder.style.marginTop = (Math.floor(height/2) )  + "px";
	adCountdownHolder.style.marginLeft = -(Math.floor(width/2)) + "px";
	
	loadVideoAd();
	
}

function loadVideoAd()
{
	if (interstitial.vidURL == "")
	{
		wwForceLog.call(wwConsole, wwPrefix, "Interstitial: No video ad provided (possibly intentional)");
		loadDisplayAd();
		return;
	}
	
	var adContainer = document.getElementById("adContainer");
	
	var width = interstitial.width;
	var height = interstitial.height;
	
	// Show video ad
	currentAdType = AdPlacement.VIDEO_AD;
	
	//fauxtransparent is because IE won't load the flash until it's visible, however it's not 
	//this also handles the white flash issue in IE where IE flashes an iframe white while it's loading
	//in a different way than setting it to visibibility=hidden, which will cause slower ad loads
	//since flash won't render until it's visible
	adContainer.innerHTML = '<ifr'+'ame id="videoplayerframe" class="fauxtransparent" style="overflow: hidden; background-color: transparent; border:0; width:'+width+'px; height:'+(height+50 /* leave room for controls */)+'px" src="./adcontainers/videoad/vidplayerframe.html'+window.location.hash.split("?")[0]+'?adType=interstitial&adconfig=' + encodeURIComponent(JSON.stringify(adConfig))+'"></ifr'+'ame>';
	
}
	
// Only show display ad if video ad fails to load
function loadDisplayAd()
{
	if (interstitial.displayURL == "")
	{
		wwForceLog.call(wwConsole, wwPrefix, "Interstitial: No display ad provided (possibly intentional)");
		closeAd();
		return;
	}
	var adContainer = document.getElementById("adContainer");
	var adControlsOverlay = document.getElementById("adControlsOverlay");
	var playPause = document.getElementById("playpause");
	var adCountdownHolder = document.getElementById("adCountdownHolder");
	
	
	adContainer.style.visibility = "hidden";
	adControlsOverlay.style.visibility = "hidden";
	adCountdownHolder.style.visibility = "hidden";
	
	var width = interstitial.width;
	var height = interstitial.height;

	// Show display ad
	currentAdType = AdPlacement.DISPLAY_AD;
	adContainer.innerHTML = '<ifr'+'ame id="inpageplayerframe" style="overflow: hidden; background-color: transparent; border:0; top: 50%; width:'+width+'px; height:'+height+'px" src="./adcontainers/display/displayadframe.html'+window.location.hash.split("?")[0]+'?adType=interstitial&adconfig=' + encodeURIComponent(JSON.stringify(adConfig))+'"></ifr'+'ame>'; 
	displayCount = interstitial.displaySecondsToClose;
	countdownInterval = window.setInterval(displayCountdownInterval, 1000);
	updateCountdown(interstitial.displaySecondsToClose, interstitial.displaySecondsToClose);
	// Because unlike video ads, controls aren't in the video player
	playPause.style.display="inline";
	adCountdownHolder.style.width = interstitial.width + "px";
	var color = window.getComputedStyle(adControlsOverlay).backgroundColor;
	adCountdownHolder.style.backgroundColor = color;
	
	
	addListener(playPause, "mouseup", buttonPlayPausePressed);
	
	
}


/*
Macros for adConfig.*.vidCountdownNumFormat 
${MM} remaining minutes for time in MM:SS format
${SS} remaining seconds for time in MM:SS format
${TMM} total minutes for time in MM:SS format
${TSS} total seconds for time in MM:SS format
${SEC} remaining seconds (where time is in only seconds)
${TSEC} total seconds (where time is in only seconds)
Example:
If there is 1 minute, 5 seconds left
${MM} = 1
${SS} = 05
${SEC} = 65
*/
function updateCountdown(remaining, duration)
{	if (remaining < 0)
		remaining = 0;
	var countdownText = adConfig[adType].vidCountdownNumFormat;
	var remainMM = Math.floor(remaining/60);
	var totalMM = Math.floor(duration/60);
	var remainSS = Math.floor(remaining - remainMM*60);
	var totalSS = Math.floor(duration - totalMM*60);
	countdownText = countdownText.replace("${MM}",remainMM);
	countdownText = countdownText.replace("${SS}",(remainSS >= 10)?remainSS : "0" + remainSS);
	countdownText = countdownText.replace("${TMM}",totalMM);
	countdownText = countdownText.replace("${TSS}",(totalSS >= 10)?totalSS : "0" + totalSS);
	countdownText = countdownText.replace("${SEC}",Math.floor(remaining));
	countdownText = countdownText.replace("${TSEC}",Math.floor(duration));
	document.getElementById("countdown_counter").innerHTML = countdownText;

}

/* Enable close button countdown functionality

*/


function setupEnableCloseButtonCountdown()
{
	document.getElementById("close").src = "./images/clear.gif";
	if (allowCloseButtonCountdownInterval != -1)
	{
		window.clearInterval(allowCloseButtonCountdownInterval);
		allowCloseButtonCountdownInterval = -1;
		allowCloseButtonCountdown = 0;
	}
	
	if (typeof(interstitial.allowCloseButtonAfter) == "undefined")
	{
		allowCloseButtonCountdown = 0;
		enableClose();
	}
	else
	{
		allowCloseButtonCountdown = interstitial.allowCloseButtonAfter;
		allowCloseButtonCountdownInterval = window.setInterval(enableCloseInterval, 1000);
		document.getElementById("until_close_text").style.display = "block";
		document.getElementById("allow_close_countdown_counter").innerHTML = allowCloseButtonCountdown;
	}
}

function enableCloseInterval()
{
	allowCloseButtonCountdown -= 1;
	document.getElementById("allow_close_countdown_counter").innerHTML = allowCloseButtonCountdown;
	if (allowCloseButtonCountdown == 0)
		enableClose();
}

function enableClose()
{
	allowCloseButtonCountdown = 0; // Just to be sure, since this can be called from outside interval
	document.getElementById("until_close_text").style.display = "none";
	if (allowCloseButtonCountdownInterval != -1)
	{
		window.clearInterval(allowCloseButtonCountdownInterval);
		allowCloseButtonCountdownInterval = -1;
	}
	document.getElementById("close").src = "./images/close.png";
	document.getElementById("close").style.cursor = "pointer";
}


/////////////

function onSuccessfulLoad()
{

 // Do this on first countdown instead because when ad servers encapsulate their video ads in SWFs, 
 // we get a successful load notice even if the SWF is not going to show anything
 // Note: This could cause interactive ads not to display if there's no countdown. Investigate in future
		if (currentAdType == AdPlacement.VIDEO_AD)
			return;

		enableUI();
}

function enableUI()
{
		uiEnabled = true;
		var adContainer = document.getElementById("adContainer");
		var adControlsOverlay = document.getElementById("adControlsOverlay");
		var adCountdownHolder = document.getElementById("adCountdownHolder");
		
		adContainer.style.visibility = "visible";
		adControlsOverlay.style.visibility = "visible";
		adCountdownHolder.style.visibility = "visible";
		document.body.style.visibility = "visible";
		document.body.style.backgroundColor = "rgba(0,0,0,0.7)";
		adContainer.style.backgroundColor = "black";

		if (document.getElementById("videoplayerframe") != null)
			document.getElementById("videoplayerframe").className="";	// get rid of fauxtransparent, see above on iframe creation
		if (document.getElementById("inpageplayerframe") != null)
			document.getElementById("inpageplayerframe").className="";	// get rid of fauxtransparent, see above on iframe creation
		
		setupEnableCloseButtonCountdown();
}

function onVideoCompleted() // called by vidplayerframe
{
	currentAdType = "";
	closeAd();
}

function onVideoError() // called by vidplayerframe
{
	currentAdType = "";
	loadDisplayAd();
}

function onDisplayError() // called by displayadframe
{
	clearInterval(countdownInterval);
	countdownInterval = -1;
	currentAdType = "";
	closeAd();
}

function displayCountdownInterval()
{
	displayCount -= 1;
	updateCountdown(displayCount, interstitial.displaySecondsToClose);
	if (displayCount == 0)
	{
		clearInterval(countdownInterval);
		closeAd();
	}
}

function buttonPlayPausePressed()
{
	if (countdownInterval != -1)
	{
		clearInterval(countdownInterval);
		countdownInterval = -1;
		document.getElementById("playpause").src="./images/play.png";
	}
	else
	{
		countdownInterval = window.setInterval(displayCountdownInterval, 1000);
		document.getElementById("playpause").src="./images/pause.png";
	}
}

function closeAd()
{
	sendMessage("closeAd", ModuleEnums.MODULE_LOADER, {});
}
var uiEnabled = false;
function onUpdateCountdown(remaining, duration)
{
 // Do this on first countdown instead because when ad servers encapsulate their video ads in SWFs, 
 // we get a successful load notice even if the SWF is not going to show anything
 // Note: This could cause interactive ads not to display if there's no countdown. Investigate in future
	if (currentAdType == AdPlacement.VIDEO_AD && uiEnabled == false)
			enableUI();
	updateCountdown(remaining, duration);
}

