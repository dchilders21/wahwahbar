console.log("In wwpsf.js...");

function getParameterByName(name)
{
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var results = regex.exec( window.location.href );
  if( results == null )
    return "";
  else
    return decodeURIComponent(results[1].replace(/\+/g, " "));
}

var wwDomain = getParameterByName("wwDomain");

var wwPath = getParameterByName("wwPath");

var wahwahQueryString = getParameterByName("wahwah");
var wahwah = JSON.parse(wahwahQueryString);

var levels = getParameterByName("levels");

// This script is XSS safe
var xssCheckPassed = false;
var domainSimple = wwDomain.split("://")[1];
domainSimple = domainSimple.split(":")[0];

// Approved list (XSS protection)
if (	domainSimple == "cdn-s.wahwahnetworks.com" ||
		domainSimple == "cdn-s.wwnstatic.com" ||
		domainSimple == "test.wahwahnetworks.com" ||
		domainSimple == "test-alt.wahwahnetworks.com" ||
		domainSimple == "wahwah.dev.reaktix.net" ||
		domainSimple == "localhost" )
	xssCheckPassed = true;
	
if (xssCheckPassed == true)
{
	// Now pull the correct .js for this version of the bar
	var jsURL = wwDomain + wwPath + '/psf/wwverpsf.js';
	console.log("Writing " + jsURL);
	document.writeln('<scr'+'ipt type="text/javascript" src="'+ jsURL + '"></scr'+'ipt>');
}
else
{
	alert("wwpsf.js: xss check failure. Not loading further.");
}