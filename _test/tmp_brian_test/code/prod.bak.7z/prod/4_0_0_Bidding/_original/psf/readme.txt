-----------------------------
Publisher Side File (PSF) 
-----------------------------

Background
----------

The publisher side file is for cases the publisher refuses
to write us directly into the page. There is little point
to writing us into an iframe, since we have a delayed load
anyway. However, some publishers still insist. What happens
is that the radio needs to expand over the page, but can't
because it's locked into an iframe. If this iframe is in a different
domain, then the wahwah bar can't access the main page
to do its work (e.g. write out the widget iframes). 

Example:
The main page could be
http://mydomain.com/articles/index.html
Then in the page, there is a 1x1 iframe that looks like the following
<iframe src="http://domain2.com/wahwah.html" width="1" height="1"></iframe>

http://domain2.com/wahwah.html writes out our wahwah bar. The problem
is that the wahwah bar is now stuck in a 1x1 iframe. Since the top level page
is on mydomain.com and domain2.com is a different domain, there's no
way for the wahwah bar to break out of the iframe.


Solution
--------

The WahWah bar psf solution solves that problem. It first attempts to break
out without a psf, for efficiency reasons. In this case, the domain is different
so it can't break out easily like that (in some cases, it may, making the
load faster).

Because it can't break out, the WahWah bar writes out an iframe on mydomain.com
which can then talk to the top level page http://mydomain.com/articles/index.html
through simple DOM manipulation. The WahWah psf solution then writes out the
bar to http://mydomain.com/articles/index.html.


*** Note: This solution has security measures to prevent cross-side
scripting vulnerabilities (xss vulnerabilities) so it is necessary
to follow instructions very carefully.


Steps per publisher
-------------------
1. Place wwpsf.html on publisher domain(s)
2. Modify wahwah object to provide info about the psf (once per domain)


wwpsf.html:

wwpsf.html goes on the publisher at any location that is on the 
SAME DOMAIN as the web page. For publishers that have multiple 
domains, the file needs to be deployed to each domain. This
includes subdomains. For instance, www.mysite.com is different
than mail.mysite.com.

All wwpsf.html does is call in wwpsf.js from a fixed location
on the cdn and/or dev servers (depending on the solution)
shared by all campaigns.


*** Note: It is recommended for a single publisher to put the wwpsf.html
file in the same location on each domain (e.g. wahwah/wwpsf.html) if publishers 
would like to use the same wahwah object across all domains. More info
on the wahwah object below.

WahWah object:

Add a parameter psf to wahwah object. e.g.: 
var wahwah = {
 ...,
psf: { file: "wahwah/wwpsf.html", levels: 1, pubdomain: "mydomain.com", friendly: true }
 ...,
};

Where ellipses represent ommited values.

Variables: 
* file: set the relative path of the psf file
* pubdomain: Sometimes, publishers have nested frames or other conditions that make 
 detection impossible. In that case, pubdomain lets you override the domain
* levels: The number of iframes up. Should be an integer. E.g. the parent frame 
 would be 1, the parent of the parent (parent.parent) would be 2, etc.
 Ignore any child frames created by wahwah for the psf solution. This should
 be purely based on where the publisher sticks us.
* friendly: Generally, there is a friendly frame check. If this parameter is set to false, 
  it's skipped. Not setting is the equivalent of true.

The following combinations are permitted:
1. file
2. file, pubdomain
3. levels and friendly can be used with 1 and 2
4. friendly can be used by itself (having no variables in psf is the equivalent of friendly: true)


The value for psf should depend on where the publisher stuck the 
file. For instance, if the psf is at 
http://mydomain.com/wahwah/wwpsf.html and the main page 




One time steps, not per publisher
---------------------------------
This only has to be done once, or on rare occasions:
1. Deploy wwpsf.js
2. Deploy wwverpsf.js with releases

wwpsf.js:
A file called wwpsf.js needs to be placed on the CDN in a location that
doesn't change but is editable on rare occasions. Currently, it resides in
http://cdn-s.wahwahnetworks.com/00BA6A/psf/wwpsf.js

This file should be
shared across all environments, and all solutions, and its sole jobs are to
provide some xss security by checking domains and then once verified
call in the version-specific psf script from the domain and path specified.

You only need to change this file when the list of allowed domains changes
or there is a drastic change to the solution.

wwverpsf.js:

This allows keeping the js that writes out the final iframe in sync with the
loader.js and other related files without requiring constant changes to wwpsf.js, which
is risky