console.log("In wwverpsf.js...");
console.log("wwDomain:" + wwDomain);
console.log("wwPath:" + wwPath);
console.log("wahwah: " + JSON.stringify(wahwah).substring(0,77) + "...");
console.log("levels:" + levels);
var access = false;
var newWindow = null;
try 
{
	var iter = window;
	for (var i = 0; i < levels + 1 /* plus 1 to account for this frame that we wrote out */; i++)
	{
		iter=iter.parent;
	}
	// attempt to create a variable and read it
	iter.___wwtest = "test";
	var a = iter.___wwtest;
	access = true;
	newWindow = iter;
}
catch(e)
{
	console.log("Error accessing main page. Check psf variables, including levels");
}

if (access == true)
{
	newWindow.wahwah = wahwah;
	
	var loaderSrc = wwDomain + wwPath + "/widget/loader.js";

	var fileref=document.createElement('script');
	fileref.setAttribute("type","text/javascript");
	fileref.setAttribute("src", loaderSrc);
	console.log("Writing out to main page: " + loaderSrc);
	if (typeof(fileref)!="undefined")
		newWindow.document.getElementsByTagName("head")[0].appendChild(fileref);
}